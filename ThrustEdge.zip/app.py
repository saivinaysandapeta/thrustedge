import streamlit as st
import pandas as pd
import numpy as np
import joblib
import plotly.graph_objects as go
import plotly.express as px
from datetime import datetime
import os

# Page configuration
st.set_page_config(
    page_title="Drone Thrust Predictor",
    page_icon="🚁",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS
st.markdown("""
<style>
    .main-header {
        font-size: 3rem;
        color: #1f77b4;
        text-align: center;
        margin-bottom: 2rem;
    }
    .metric-card {
        background-color: #f0f2f6;
        padding: 1rem;
        border-radius: 0.5rem;
        margin: 0.5rem 0;
    }
    .stDownloadButton button {
        background-color: #4CAF50;
        color: white;
        font-weight: bold;
    }
</style>
""", unsafe_allow_html=True)

class ThrustPredictor:
    """Thrust prediction engine"""
    
    def __init__(self):
        self.AIR_DENSITY = 1.225
        self.g = 9.81
        self.load_calibrations()
    
    def load_calibrations(self):
        """Load prop calibrations"""
        cal_path = "models/calibrations/calibration_index.pkl"
        if os.path.exists(cal_path):
            self.calibrations = joblib.load(cal_path)
        else:
            self.calibrations = {}
    
    def get_available_props(self):
        """Get list of available props"""
        return sorted(self.calibrations.keys())
    
    def ct_model(self, rpm, a, b, c):
        """C_T model"""
        return a + b * np.log(rpm + 1) + c * rpm / 10000
    
    def cp_model(self, rpm, a, b, c):
        """C_P model"""
        return a + b * np.log(rpm + 1) + c * rpm / 10000
    
    def predict_single(self, motor_kv, voltage, prop_key, throttle, num_motors=4):
        """Single point prediction"""
        
        if prop_key not in self.calibrations:
            return None
        
        cal = self.calibrations[prop_key]
        prop_d = cal['prop_diameter']
        prop_p = cal['prop_pitch']
        
        # Calculate RPM
        rpm = motor_kv * voltage * (throttle / 100)
        
        # Calculate C_T
        ct_params = cal['ct_params']
        ct = self.ct_model(rpm, *ct_params)
        
        # Calculate thrust per motor
        D = prop_d * 0.0254
        n = rpm / 60
        
        thrust_N_per_motor = ct * self.AIR_DENSITY * (n ** 2) * (D ** 4)
        thrust_kgf_per_motor = thrust_N_per_motor / self.g
        
        # Total thrust
        total_thrust_N = thrust_N_per_motor * num_motors
        total_thrust_kgf = thrust_kgf_per_motor * num_motors
        
        # Power
        power_W_per_motor = None
        total_power_W = None
        current_A_per_motor = None
        total_current_A = None
        
        if cal['cp_params']:
            cp_params = cal['cp_params']
            cp = self.cp_model(rpm, *cp_params)
            
            power_W_per_motor = cp * self.AIR_DENSITY * (n ** 3) * (D ** 5)
            total_power_W = power_W_per_motor * num_motors
            current_A_per_motor = power_W_per_motor / voltage
            total_current_A = current_A_per_motor * num_motors
        
        return {
            'rpm': rpm,
            'ct': ct,
            'thrust_N_per_motor': thrust_N_per_motor,
            'thrust_kgf_per_motor': thrust_kgf_per_motor,
            'total_thrust_N': total_thrust_N,
            'total_thrust_kgf': total_thrust_kgf,
            'power_W_per_motor': power_W_per_motor,
            'total_power_W': total_power_W,
            'current_A_per_motor': current_A_per_motor,
            'total_current_A': total_current_A,
            'prop_d': prop_d,
            'prop_p': prop_p
        }
    
    def predict_sweep(self, motor_kv, voltage, prop_key, num_motors=4, 
                     throttle_min=10, throttle_max=100, throttle_step=5):
        """Throttle sweep prediction"""
        
        throttles = np.arange(throttle_min, throttle_max + throttle_step, throttle_step)
        results = []
        
        for throttle in throttles:
            pred = self.predict_single(motor_kv, voltage, prop_key, throttle, num_motors)
            
            if pred:
                results.append({
                    'Throttle (%)': throttle,
                    'RPM': pred['rpm'],
                    'Thrust per Motor (kgf)': pred['thrust_kgf_per_motor'],
                    'Total Thrust (kgf)': pred['total_thrust_kgf'],
                    'Power per Motor (W)': pred['power_W_per_motor'],
                    'Total Power (W)': pred['total_power_W'],
                    'Current per Motor (A)': pred['current_A_per_motor'],
                    'Total Current (A)': pred['total_current_A']
                })
        
        return pd.DataFrame(results)


# Initialize predictor
@st.cache_resource
def get_predictor():
    return ThrustPredictor()

predictor = get_predictor()

# Header
st.markdown('<h1 class="main-header">🚁 Drone Thrust Prediction System</h1>', unsafe_allow_html=True)
st.markdown("**Predict motor-propeller-battery performance with 52 calibrated propellers**")

# Sidebar - Configuration
st.sidebar.header("⚙️ Configuration")

# Mode selection
mode = st.sidebar.radio("Prediction Mode", 
                        ["Single Point", "Throttle Sweep", "Compare Props"])

st.sidebar.markdown("---")

# Motor configuration
st.sidebar.subheader("🔧 Motor & Battery")
motor_kv = st.sidebar.number_input("Motor KV", min_value=100, max_value=5000, value=2400, step=50)
voltage = st.sidebar.selectbox("Battery Voltage (V)", 
                                [3.7, 7.4, 11.1, 14.8, 22.2, 25.9],
                                index=3)

# Propeller selection
st.sidebar.subheader("🔩 Propeller")
available_props = predictor.get_available_props()

# Filter props by diameter
diameters = sorted(set([float(p.split('x')[0]) for p in available_props]))
selected_diameter = st.sidebar.selectbox("Diameter (inches)", diameters, index=10)

# Filter props by selected diameter
filtered_props = [p for p in available_props if p.startswith(f"{selected_diameter:.1f}x")]
prop_key = st.sidebar.selectbox("Propeller", filtered_props)

# ESC and quad configuration
st.sidebar.subheader("⚡ ESC & Quad Config")
num_motors = st.sidebar.slider("Number of Motors", min_value=1, max_value=8, value=4)
esc_rating = st.sidebar.number_input("ESC Current Rating (A)", min_value=10, max_value=120, value=40)

st.sidebar.markdown("---")

# ==================== SINGLE POINT MODE ====================
if mode == "Single Point":
    st.header("📊 Single Point Prediction")
    
    col1, col2 = st.columns([1, 2])
    
    with col1:
        throttle = st.slider("Throttle (%)", min_value=0, max_value=100, value=75, step=5)
        
        if st.button("🚀 Predict", type="primary"):
            result = predictor.predict_single(motor_kv, voltage, prop_key, throttle, num_motors)
            
            if result:
                st.success("✅ Prediction Complete!")
                
                # Display metrics
                st.subheader("Performance Metrics")
                
                metric_col1, metric_col2, metric_col3 = st.columns(3)
                
                with metric_col1:
                    st.metric("Total Thrust", f"{result['total_thrust_kgf']:.2f} kgf", 
                             f"{result['thrust_kgf_per_motor']:.2f} kgf/motor")
                    st.metric("RPM", f"{result['rpm']:.0f}")
                
                with metric_col2:
                    if result['total_power_W']:
                        st.metric("Total Power", f"{result['total_power_W']:.1f} W",
                                 f"{result['power_W_per_motor']:.1f} W/motor")
                        st.metric("Flight Time Estimate", 
                                 f"{(voltage * 5000) / result['total_power_W'] * 60:.1f} min",
                                 help="Based on 5Ah battery")
                
                with metric_col3:
                    if result['total_current_A']:
                        st.metric("Total Current", f"{result['total_current_A']:.1f} A",
                                 f"{result['current_A_per_motor']:.1f} A/motor")
                        
                        # ESC check
                        if result['current_A_per_motor'] > esc_rating * 0.8:
                            st.error(f"⚠️ Current exceeds 80% ESC rating!")
                        else:
                            st.success(f"✓ Within ESC limits")
                
                # Configuration summary
                st.subheader("Configuration Summary")
                config_data = {
                    'Parameter': ['Motor KV', 'Battery Voltage', 'Propeller', 
                                'Number of Motors', 'Throttle', 'Thrust-to-Weight Ratio'],
                    'Value': [f"{motor_kv} KV", f"{voltage} V", 
                             f"{result['prop_d']:.1f}x{result['prop_p']:.1f}\"",
                             num_motors, f"{throttle}%",
                             f"{result['total_thrust_kgf'] / 2.0:.2f}:1 (assuming 2kg AUW)"]
                }
                st.table(pd.DataFrame(config_data))

# ==================== THROTTLE SWEEP MODE ====================
elif mode == "Throttle Sweep":
    st.header("📈 Throttle Sweep Analysis")
    
    col1, col2 = st.columns([1, 3])
    
    with col1:
        throttle_min = st.number_input("Min Throttle (%)", 0, 100, 10)
        throttle_max = st.number_input("Max Throttle (%)", 0, 100, 100)
        throttle_step = st.number_input("Step (%)", 1, 20, 5)
        
        if st.button("🔄 Generate Sweep", type="primary"):
            df = predictor.predict_sweep(motor_kv, voltage, prop_key, num_motors,
                                        throttle_min, throttle_max, throttle_step)
            
            st.session_state['sweep_data'] = df
    
    # Display results
    if 'sweep_data' in st.session_state:
        df = st.session_state['sweep_data']
        
        with col2:
            # Plot thrust vs throttle
            fig_thrust = go.Figure()
            fig_thrust.add_trace(go.Scatter(x=df['Throttle (%)'], 
                                           y=df['Total Thrust (kgf)'],
                                           mode='lines+markers',
                                           name='Total Thrust',
                                           line=dict(color='blue', width=3)))
            fig_thrust.update_layout(title="Thrust vs Throttle",
                                    xaxis_title="Throttle (%)",
                                    yaxis_title="Total Thrust (kgf)",
                                    height=400)
            st.plotly_chart(fig_thrust, use_container_width=True)
        
        # Power and current plots
        if df['Total Power (W)'].notna().any():
            col_p1, col_p2 = st.columns(2)
            
            with col_p1:
                fig_power = go.Figure()
                fig_power.add_trace(go.Scatter(x=df['Throttle (%)'], 
                                              y=df['Total Power (W)'],
                                              mode='lines+markers',
                                              line=dict(color='orange', width=3)))
                fig_power.update_layout(title="Power vs Throttle",
                                       xaxis_title="Throttle (%)",
                                       yaxis_title="Total Power (W)",
                                       height=350)
                st.plotly_chart(fig_power, use_container_width=True)
            
            with col_p2:
                fig_current = go.Figure()
                fig_current.add_trace(go.Scatter(x=df['Throttle (%)'], 
                                                y=df['Total Current (A)'],
                                                mode='lines+markers',
                                                line=dict(color='red', width=3)))
                fig_current.add_hline(y=esc_rating * num_motors, 
                                     line_dash="dash", 
                                     annotation_text="ESC Limit",
                                     line_color="red")
                fig_current.update_layout(title="Current vs Throttle",
                                         xaxis_title="Throttle (%)",
                                         yaxis_title="Total Current (A)",
                                         height=350)
                st.plotly_chart(fig_current, use_container_width=True)
        
        # Data table
        st.subheader("📋 Complete Data Table")
        st.dataframe(df, use_container_width=True)
        
        # Download button
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"prediction_{motor_kv}kv_{prop_key.replace('.', '_')}_{voltage}v_{timestamp}.csv"
        
        csv = df.to_csv(index=False)
        st.download_button(
            label="📥 Download CSV",
            data=csv,
            file_name=filename,
            mime="text/csv"
        )

# ==================== COMPARE PROPS MODE ====================
elif mode == "Compare Props":
    st.header("⚖️ Compare Multiple Propellers")
    
    throttle = st.slider("Test Throttle (%)", 0, 100, 75, 5)
    
    # Multi-select props
    selected_props = st.multiselect(
        "Select Propellers to Compare (max 5)",
        available_props,
        default=[prop_key] if prop_key in available_props else []
    )
    
    if st.button("🔍 Compare", type="primary") and selected_props:
        comparison_data = []
        
        for prop in selected_props[:5]:  # Limit to 5
            result = predictor.predict_single(motor_kv, voltage, prop, throttle, num_motors)
            
            if result:
                comparison_data.append({
                    'Propeller': prop,
                    'RPM': result['rpm'],
                    'Total Thrust (kgf)': result['total_thrust_kgf'],
                    'Total Power (W)': result['total_power_W'],
                    'Total Current (A)': result['total_current_A'],
                    'Efficiency (g/W)': (result['total_thrust_kgf'] * 1000 / result['total_power_W']) 
                                       if result['total_power_W'] else None
                })
        
        df_comp = pd.DataFrame(comparison_data)
        
        # Bar charts
        col1, col2 = st.columns(2)
        
        with col1:
            fig = px.bar(df_comp, x='Propeller', y='Total Thrust (kgf)',
                        title="Thrust Comparison",
                        color='Total Thrust (kgf)',
                        color_continuous_scale='Blues')
            st.plotly_chart(fig, use_container_width=True)
        
        with col2:
            if df_comp['Total Power (W)'].notna().any():
                fig = px.bar(df_comp, x='Propeller', y='Total Power (W)',
                            title="Power Comparison",
                            color='Total Power (W)',
                            color_continuous_scale='Oranges')
                st.plotly_chart(fig, use_container_width=True)
        
        # Comparison table
        st.subheader("Detailed Comparison")
        st.dataframe(df_comp, use_container_width=True)
        
        # Best prop recommendation
        if not df_comp.empty:
            best_thrust = df_comp.loc[df_comp['Total Thrust (kgf)'].idxmax()]
            best_efficiency = df_comp.loc[df_comp['Efficiency (g/W)'].idxmax()] if 'Efficiency (g/W)' in df_comp else None
            
            rec_col1, rec_col2 = st.columns(2)
            
            with rec_col1:
                st.success(f"🏆 **Best Thrust:** {best_thrust['Propeller']} ({best_thrust['Total Thrust (kgf)']:.2f} kgf)")
            
            if best_efficiency is not None:
                with rec_col2:
                    st.success(f"⚡ **Most Efficient:** {best_efficiency['Propeller']} ({best_efficiency['Efficiency (g/W)']:.1f} g/W)")

# Footer
st.markdown("---")
st.markdown("**🚁 Drone Thrust Prediction System** | Powered by 52 calibrated propellers | Built with Streamlit")
