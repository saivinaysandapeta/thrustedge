import pandas as pd
import numpy as np

INPUT_CSV = "data/processed/raw_combined.csv"
OUTPUT_CSV = "data/processed/train_dataset.csv"

def convert_range_to_number(value):
    """Convert range strings like '3-5' or '25-35' to average number"""
    if pd.isna(value):
        return None
    
    # Convert to string and clean
    value_str = str(value).strip()
    
    # Check if it's a range (contains dash)
    if '-' in value_str:
        try:
            # Split by dash and take average
            parts = value_str.split('-')
            low = float(parts[0])
            high = float(parts[1])
            return (low + high) / 2
        except:
            return None
    
    # Try to convert directly to float
    try:
        return float(value_str)
    except:
        return None

def main():
    print("=" * 60)
    print("PREPARING TRAINING DATASET")
    print("=" * 60)
    
    df = pd.read_csv(INPUT_CSV)
    print(f"\nLoaded {len(df)} rows with {len(df.columns)} columns")
    
    # Rename to standardized names (case-insensitive matching)
    rename_map = {}
    for col in df.columns:
        col_lower = col.lower().strip()
        
        if 'throttle' in col_lower and ('µ' in col_lower or 'us' in col_lower or 's)' in col_lower):
            rename_map[col] = "Throttle_us"
        elif 'rotation' in col_lower and 'speed' in col_lower:
            rename_map[col] = "RPM"
        elif 'thrust' in col_lower and 'kgf' in col_lower:
            rename_map[col] = "Thrust_kgf"
        elif col_lower.startswith('voltage') or (col_lower.startswith('voltage') and 'v' in col_lower):
            rename_map[col] = "Voltage_V"
        elif col_lower.startswith('current') and 'a' in col_lower:
            rename_map[col] = "Current_A"
        elif 'electrical' in col_lower and 'power' in col_lower:
            rename_map[col] = "ElecPower_W"
        elif 'mechanical' in col_lower and 'power' in col_lower:
            rename_map[col] = "MechPower_W"
        elif 'motor' in col_lower and 'esc' in col_lower and 'efficiency' in col_lower:
            rename_map[col] = "Motor_ESC_eff_pct"
        elif 'propeller' in col_lower and 'efficiency' in col_lower and 'system' not in col_lower:
            rename_map[col] = "Prop_eff_gf_per_W"
        elif 'propulsion' in col_lower and 'efficiency' in col_lower:
            rename_map[col] = "System_eff_gf_per_W"
        elif 'motor' in col_lower and 'kv' in col_lower:
            rename_map[col] = "Motor_Kv"
        elif 'diameter' in col_lower or 'diamet' in col_lower or 'diamter' in col_lower or 'diagram' in col_lower:
            if 'propeller' in col_lower or 'prop' in col_lower:
                rename_map[col] = "Prop_D_inch"
        elif ('pitch' in col_lower or 'pith' in col_lower) and ('propeller' in col_lower or 'prop' in col_lower):
            rename_map[col] = "Prop_P_inch"
        elif 'esc' in col_lower and 'limit' in col_lower:
            rename_map[col] = "ESC_limit_A"
    
    print(f"\nRenamed {len(rename_map)} columns")
    df = df.rename(columns=rename_map)
    
    # Now build new dataframe with consolidated columns
    print("\nConsolidating duplicate columns...")
    
    consolidated = {}
    
    # Add source file
    if 'source_file' in df.columns:
        consolidated['source_file'] = df['source_file']
    
    important_cols = [
        'Throttle_us',
        'RPM',
        'Thrust_kgf',
        'Voltage_V',
        'Current_A',
        'ElecPower_W',
        'MechPower_W',
        'Motor_ESC_eff_pct',
        'Prop_eff_gf_per_W',
        'System_eff_gf_per_W',
        'Motor_Kv',
        'Prop_D_inch',
        'Prop_P_inch',
        'ESC_limit_A',
    ]
    
    for col_name in important_cols:
        if col_name in df.columns:
            # Handle case where multiple columns have same name after rename
            col_data = df[col_name]
            
            if isinstance(col_data, pd.DataFrame):
                # Multiple columns - combine by taking first non-null
                print(f"  {col_name}: merging {col_data.shape[1]} duplicate columns")
                result = col_data.iloc[:, 0].copy()
                for i in range(1, col_data.shape[1]):
                    result = result.fillna(col_data.iloc[:, i])
                consolidated[col_name] = result
            else:
                # Single column
                consolidated[col_name] = col_data
            
            non_null = consolidated[col_name].notna().sum()
            print(f"  {col_name}: {non_null}/{len(df)} non-null values")
    
    df = pd.DataFrame(consolidated)
    
    # Convert range values to numbers
    print("\nConverting range values to numbers...")
    numeric_cols = ['Motor_Kv', 'Prop_D_inch', 'Prop_P_inch', 'ESC_limit_A', 
                    'Throttle_us', 'Voltage_V', 'RPM', 'Thrust_kgf', 
                    'ElecPower_W', 'Current_A']
    
    for col in numeric_cols:
        if col in df.columns:
            before_null = df[col].isna().sum()
            df[col] = df[col].apply(convert_range_to_number)
            after_null = df[col].isna().sum()
            converted = after_null - before_null
            if converted > 0:
                print(f"  {col}: converted {converted} range values")
    
    print(f"\nAfter conversion: {df.shape}")
    
    # Check which columns we have
    needed = ["Motor_Kv", "Prop_D_inch", "Prop_P_inch", "ESC_limit_A",
              "Throttle_us", "Voltage_V", "RPM", "Thrust_kgf"]
    
    print("\nChecking for required columns:")
    missing_cols = []
    for col in needed:
        if col in df.columns:
            non_null = df[col].notna().sum()
            print(f"  ✓ {col}: {non_null}/{len(df)} non-null")
        else:
            print(f"  ✗ {col}: MISSING")
            missing_cols.append(col)
    
    if missing_cols:
        print(f"\nERROR: Missing columns: {missing_cols}")
        return
    
    # Drop rows with missing essential data
    before = len(df)
    df = df.dropna(subset=needed)
    print(f"\nDropped {before - len(df)} rows with missing essential data")
    print(f"Remaining: {len(df)} rows")
    
    if len(df) == 0:
        print("\nERROR: No valid data remaining after removing NaN!")
        return
    
    # Filter invalid data
    df = df[df["RPM"] >= 0]
    df = df[df["Thrust_kgf"].between(-0.1, 10)]
    print(f"After filtering invalid values: {len(df)} rows")
    
    # Define feature and target columns
    feature_cols = [
        "Motor_Kv",
        "Prop_D_inch",
        "Prop_P_inch",
        "ESC_limit_A",
        "Throttle_us",
        "Voltage_V",
    ]
    
    target_cols = [
        "RPM",
        "Thrust_kgf",
        "ElecPower_W",
        "Prop_eff_gf_per_W",
    ]
    
    # Keep only columns that exist
    available_targets = [c for c in target_cols if c in df.columns]
    keep = feature_cols + available_targets + (["source_file"] if "source_file" in df.columns else [])
    df = df[keep]
    
    # Save
    df.to_csv(OUTPUT_CSV, index=False)
    print(f"\n{'='*60}")
    print("✓ SUCCESS!")
    print(f"{'='*60}")
    print(f"Saved: {OUTPUT_CSV}")
    print(f"Shape: {df.shape}")
    print(f"Features: {feature_cols}")
    print(f"Targets: {available_targets}")
    
    print("\nSample data (first 5 rows):")
    print(df.head())
    
    print("\nData statistics:")
    print(df[feature_cols + available_targets].describe())

if __name__ == "__main__":
    main()
