import pandas as pd
import numpy as np

print("="*70)
print("VALIDATING PHYSICS PATTERNS IN YOUR DATASET")
print("="*70)

# Load the training dataset
df = pd.read_csv("data/processed/train_dataset.csv")
print(f"\nLoaded {len(df)} samples\n")

# Filter active samples (non-zero RPM)
df_active = df[df['RPM'] > 100].copy()
print(f"Active samples (RPM > 100): {len(df_active)}\n")

print("="*70)
print("PATTERN 1: RPM ∝ Motor_Kv × Voltage")
print("="*70)

# Calculate theoretical RPM
df_active['Theoretical_RPM'] = df_active['Motor_Kv'] * df_active['Voltage_V']
df_active['RPM_ratio'] = df_active['RPM'] / df_active['Theoretical_RPM']

correlation_rpm = df_active['RPM'].corr(df_active['Theoretical_RPM'])
print(f"\nCorrelation between Actual RPM and (Kv × Voltage): {correlation_rpm:.4f}")
print(f"Interpretation: 1.0 = perfect match, >0.9 = strong relationship")

# Sample comparisons
print("\n📌 Sample Data (Random 10 tests):")
print(f"{'Motor Kv':<10} {'Voltage':<10} {'Theoretical':<12} {'Actual RPM':<12} {'Ratio':<8}")
print("-" * 60)
sample = df_active.sample(min(10, len(df_active)))
for idx, row in sample.iterrows():
    ratio = row['RPM'] / row['Theoretical_RPM'] if row['Theoretical_RPM'] > 0 else 0
    print(f"{row['Motor_Kv']:<10.0f} {row['Voltage_V']:<10.1f} {row['Theoretical_RPM']:<12.0f} {row['RPM']:<12.0f} {ratio:<8.3f}")

mean_ratio = df_active['RPM_ratio'].mean()
print(f"\nMean RPM ratio (Actual/Theoretical): {mean_ratio:.3f}")
print(f"➜ Ratio < 1.0 is EXPECTED (propeller load reduces RPM)")
print(f"➜ {'✓ PATTERN CONFIRMED' if correlation_rpm > 0.85 else '✗ Pattern weak'}")

print("\n" + "="*70)
print("PATTERN 2: Thrust ∝ RPM² × Diameter⁴")
print("="*70)

# Calculate thrust predictor
df_active['Thrust_predictor'] = (df_active['RPM'] ** 2) * (df_active['Prop_D_inch'] ** 4)
correlation_thrust = df_active['Thrust_kgf'].corr(df_active['Thrust_predictor'])

print(f"\nCorrelation between Thrust and (RPM² × D⁴): {correlation_thrust:.4f}")
print(f"Interpretation: >0.85 = momentum theory holds strongly")

# Calculate thrust coefficient
df_active['Thrust_coeff'] = df_active['Thrust_kgf'] / (df_active['Thrust_predictor'] + 1e-10) * 1e9

print("\n📌 Thrust Scaling Examples:")
print(f"{'Prop D':<8} {'RPM':<8} {'Thrust (kgf)':<14} {'RPM²×D⁴':<15} {'Coefficient':<12}")
print("-" * 70)
samples_thrust = df_active[df_active['Thrust_kgf'] > 0.05].sample(min(8, len(df_active)))
for idx, row in samples_thrust.iterrows():
    print(f"{row['Prop_D_inch']:<8.1f} {row['RPM']:<8.0f} {row['Thrust_kgf']:<14.4f} {row['Thrust_predictor']:<15.2e} {row['Thrust_coeff']:<12.2f}")

print(f"\n➜ {'✓ PATTERN CONFIRMED' if correlation_thrust > 0.85 else '✗ Pattern weak'}")

print("\n" + "="*70)
print("PATTERN 3: Power ∝ RPM³ × Diameter⁵")
print("="*70)

# Calculate power predictor
df_active['Power_predictor'] = (df_active['RPM'] ** 3) * (df_active['Prop_D_inch'] ** 5)
correlation_power = df_active['ElecPower_W'].corr(df_active['Power_predictor'])

print(f"\nCorrelation between Power and (RPM³ × D⁵): {correlation_power:.4f}")
print(f"Interpretation: >0.80 = power scaling law confirmed")

df_active['Power_coeff'] = df_active['ElecPower_W'] / (df_active['Power_predictor'] + 1e-10) * 1e15

print("\n📌 Power Scaling Examples:")
print(f"{'Prop D':<8} {'RPM':<8} {'Power (W)':<12} {'RPM³×D⁵':<15} {'Coefficient':<12}")
print("-" * 70)
samples_power = df_active[df_active['ElecPower_W'] > 10].sample(min(8, len(df_active)))
for idx, row in samples_power.iterrows():
    print(f"{row['Prop_D_inch']:<8.1f} {row['RPM']:<8.0f} {row['ElecPower_W']:<12.1f} {row['Power_predictor']:<15.2e} {row['Power_coeff']:<12.2f}")

print(f"\n➜ {'✓ PATTERN CONFIRMED' if correlation_power > 0.80 else '✗ Pattern weak'}")

print("\n" + "="*70)
print("PATTERN 4: Non-linear Efficiency Curves")
print("="*70)

# Calculate efficiency
df_active['Efficiency_g_per_W'] = (df_active['Thrust_kgf'] * 1000) / (df_active['ElecPower_W'] + 0.1)

# Group by throttle
df_active['Throttle_bin'] = pd.cut(
    df_active['Throttle_us'], 
    bins=[1000, 1200, 1400, 1600, 1800, 2000],
    labels=['Low\n1000-1200', 'Med-Low\n1200-1400', 'Medium\n1400-1600', 
            'Med-High\n1600-1800', 'High\n1800-2000']
)

print("\nEfficiency (grams thrust per Watt) by Throttle Range:")
print(f"{'Throttle Range':<20} {'Mean Eff':<12} {'Std Dev':<12} {'Samples':<10}")
print("-" * 60)
eff_stats = df_active.groupby('Throttle_bin', observed=True)['Efficiency_g_per_W'].agg(['mean', 'std', 'count'])
for idx, row in eff_stats.iterrows():
    print(f"{str(idx):<20} {row['mean']:<12.2f} {row['std']:<12.2f} {int(row['count']):<10}")

efficiency_variation = eff_stats['mean'].std()
print(f"\nEfficiency standard deviation across throttle: {efficiency_variation:.2f}")
print(f"➜ {'✓ NON-LINEAR behavior detected' if efficiency_variation > 1.0 else '○ Relatively linear'}")

# Motor Kv effect
print("\nEfficiency by Motor Kv:")
print(f"{'Kv Range':<20} {'Mean Eff':<12} {'Samples':<10}")
print("-" * 50)
df_active['Kv_bin'] = pd.cut(df_active['Motor_Kv'], bins=5)
kv_stats = df_active.groupby('Kv_bin', observed=True)['Efficiency_g_per_W'].agg(['mean', 'count'])
for idx, row in kv_stats.iterrows():
    print(f"{str(idx):<20} {row['mean']:<12.2f} {int(row['count']):<10}")

print("\n" + "="*70)
print("FINAL VALIDATION SUMMARY")
print("="*70)

results = {
    'RPM ∝ Kv×V': correlation_rpm,
    'Thrust ∝ RPM²×D⁴': correlation_thrust,
    'Power ∝ RPM³×D⁵': correlation_power,
    'Non-linear curves': 'Detected' if efficiency_variation > 1.0 else 'Weak'
}

print("\nPattern Validation Results:")
print(f"{'Pattern':<25} {'Correlation':<15} {'Status':<15}")
print("-" * 60)
print(f"{'RPM ∝ Kv×V':<25} {correlation_rpm:<15.4f} {'✓ STRONG' if correlation_rpm > 0.85 else '✗ WEAK'}")
print(f"{'Thrust ∝ RPM²×D⁴':<25} {correlation_thrust:<15.4f} {'✓ STRONG' if correlation_thrust > 0.85 else '✗ WEAK'}")
print(f"{'Power ∝ RPM³×D⁵':<25} {correlation_power:<15.4f} {'✓ STRONG' if correlation_power > 0.80 else '✗ WEAK'}")
print(f"{'Non-linear efficiency':<25} {'σ=' + f'{efficiency_variation:.2f}':<15} {'✓ DETECTED' if efficiency_variation > 1.0 else '○ WEAK'}")

all_strong = all([
    correlation_rpm > 0.85,
    correlation_thrust > 0.85,
    correlation_power > 0.80
])

print("\n" + "="*70)
if all_strong:
    print("✅ CONCLUSION: Your dataset STRONGLY follows fundamental physics!")
    print("   ML model can reliably interpolate for new combinations.")
else:
    print("⚠️  CONCLUSION: Some physics patterns are weak in your data.")
    print("   This may affect prediction accuracy for new combinations.")
print("="*70)

# Save detailed analysis
output_file = "data/processed/physics_validation.csv"
df_active.to_csv(output_file, index=False)
print(f"\n✓ Full analysis saved to: {output_file}")
print("  Open in Excel to explore patterns yourself!")
