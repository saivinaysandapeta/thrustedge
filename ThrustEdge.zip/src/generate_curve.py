import numpy as np
import pandas as pd
import joblib
import os

MODEL_DIR = "models"

def load_model():
    model = joblib.load(f"{MODEL_DIR}/propulsion_model.pkl")
    scaler = joblib.load(f"{MODEL_DIR}/feature_scaler.pkl")
    feature_cols = joblib.load(f"{MODEL_DIR}/feature_columns.pkl")
    target_cols = joblib.load(f"{MODEL_DIR}/target_columns.pkl")
    return model, scaler, feature_cols, target_cols

def generate_csv_for_combo(motor_kv, esc_limit, battery_v, prop_d, prop_p,
                           throttle_min=1100, throttle_max=1900, throttle_step=50,
                           out_path="data/processed/predicted_curve.csv"):
    
    print("=" * 60)
    print("GENERATING PREDICTION CSV")
    print("=" * 60)
    print(f"\nInput parameters:")
    print(f"  Motor Kv: {motor_kv}")
    print(f"  ESC limit: {esc_limit} A")
    print(f"  Battery: {battery_v} V")
    print(f"  Propeller: {prop_d}\" x {prop_p}\"")
    print(f"  Throttle range: {throttle_min} - {throttle_max} µs")
    
    model, scaler, feature_cols, target_cols = load_model()
    
    throttles = np.arange(throttle_min, throttle_max + 1, throttle_step)
    
    rows = []
    for t in throttles:
        feature_dict = {
            "Motor_Kv": motor_kv,
            "Prop_D_inch": prop_d,
            "Prop_P_inch": prop_p,
            "ESC_limit_A": esc_limit,
            "Throttle_us": t,
            "Voltage_V": battery_v,
        }
        x = np.array([[feature_dict[c] for c in feature_cols]])
        x_scaled = scaler.transform(x)
        y_pred = model.predict(x_scaled)[0]
        
        row = {
            "Throttle_us": t,
            "Motor_Kv": motor_kv,
            "Prop_D_inch": prop_d,
            "Prop_P_inch": prop_p,
            "ESC_limit_A": esc_limit,
            "Voltage_V": battery_v,
        }
        for name, value in zip(target_cols, y_pred):
            row[name] = value
        rows.append(row)
    
    out_df = pd.DataFrame(rows)
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    out_df.to_csv(out_path, index=False)
    
    print(f"\n✓ Generated {len(out_df)} predictions")
    print(f"✓ Saved to: {out_path}")
    print("\nFirst few predictions:")
    print(out_df.head())

if __name__ == "__main__":
    # Example: Generate predictions for a new combination
    generate_csv_for_combo(
        motor_kv=2850,
        esc_limit=30,
        battery_v=7.4,
        prop_d=7.0,
        prop_p=6.0,
        out_path="data/processed/predicted_2850kv_7x6_30A.csv"
    )
