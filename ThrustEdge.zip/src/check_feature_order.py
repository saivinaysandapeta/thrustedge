import joblib

MODEL_DIR = "models"

print("="*70)
print("CHECKING ENHANCED MODEL FEATURE ORDER")
print("="*70)

# Load the saved feature order
features = joblib.load(f"{MODEL_DIR}/feature_columns_enhanced.pkl")

print(f"\nThe model expects exactly {len(features)} features in THIS order:")
print()
for i, feature in enumerate(features, 1):
    print(f"{i:2d}. {feature}")

print("\n" + "="*70)
print("COPY THIS EXACT ORDER TO YOUR PREDICTION SCRIPTS!")
print("="*70)
