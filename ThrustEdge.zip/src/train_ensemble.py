import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import StandardScaler
from sklearn.multioutput import MultiOutputRegressor
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
import xgboost as xgb
import joblib
import os

DATA_CSV = "data/processed/train_dataset.csv"
MODEL_DIR = "models"

def create_physics_features(df):
    """Create physics-informed engineered features"""
    df = df.copy()
    
    # Normalize throttle to 0-1 range
    df['Throttle_norm'] = (df['Throttle_us'] - 1000) / 1000
    
    # FEATURE 1: Theoretical RPM (electrical domain)
    df['Theoretical_RPM'] = df['Motor_Kv'] * df['Voltage_V'] * df['Throttle_norm']
    
    # FEATURE 2: Propeller loading factor
    df['Prop_load'] = df['Prop_D_inch'] ** 2 * df['Prop_P_inch']
    
    # FEATURE 3: Disc area
    df['Disc_area'] = np.pi * (df['Prop_D_inch'] / 2) ** 2
    
    # FEATURE 4: Tip speed potential
    df['Tip_speed_factor'] = df['Motor_Kv'] * df['Voltage_V'] * df['Prop_D_inch'] * df['Throttle_norm']
    
    # FEATURE 5: Power density
    df['Power_density'] = df['Motor_Kv'] * df['Voltage_V'] / (df['ESC_limit_A'] + 0.1)
    
    # FEATURE 6: Aspect ratio (diameter to pitch)
    df['Aspect_ratio'] = df['Prop_D_inch'] / (df['Prop_P_inch'] + 0.1)
    
    # FEATURE 7: Voltage-ESC interaction
    df['V_times_ESC'] = df['Voltage_V'] * df['ESC_limit_A']
    
    # FEATURE 8: Throttle squared (for non-linear response)
    df['Throttle_squared'] = df['Throttle_norm'] ** 2
    
    # FEATURE 9: Kv category (low/med/high)
    df['Kv_category'] = pd.cut(df['Motor_Kv'], bins=[0, 1500, 3000, 10000], labels=[0, 1, 2])
    df['Kv_category'] = df['Kv_category'].astype(float)
    
    return df

def main():
    print("=" * 70)
    print("ENHANCED MODEL TRAINING WITH PHYSICS FEATURES")
    print("=" * 70)
    
    # Load data
    df = pd.read_csv(DATA_CSV)
    print(f"\nLoaded {len(df)} samples")
    
    # Create enhanced features
    print("\nCreating physics-informed features...")
    df = create_physics_features(df)
    
    # Original features
    original_features = [
        "Motor_Kv",
        "Prop_D_inch",
        "Prop_P_inch",
        "ESC_limit_A",
        "Throttle_us",
        "Voltage_V",
    ]
    
    # Enhanced features
    enhanced_features = [
        "Motor_Kv",
        "Prop_D_inch",
        "Prop_P_inch",
        "ESC_limit_A",
        "Voltage_V",
        "Throttle_norm",
        "Theoretical_RPM",
        "Prop_load",
        "Disc_area",
        "Tip_speed_factor",
        "Power_density",
        "Aspect_ratio",
        "V_times_ESC",
        "Throttle_squared",
        "Kv_category",
    ]
    
    # Target columns
    target_cols = []
    candidate_targets = ["RPM", "Thrust_kgf", "ElecPower_W", "Prop_eff_gf_per_W"]
    
    print("\nChecking target columns...")
    for col in candidate_targets:
        if col in df.columns:
            nan_pct = (df[col].isna().sum() / len(df)) * 100
            if nan_pct < 50:
                target_cols.append(col)
                print(f"  ✓ {col}: {nan_pct:.1f}% NaN")
            else:
                print(f"  ✗ {col}: {nan_pct:.1f}% NaN (skipped)")
    
    # Drop NaN
    all_needed = enhanced_features + target_cols
    before = len(df)
    df = df.dropna(subset=all_needed)
    print(f"\nDropped {before - len(df)} rows with NaN")
    print(f"Final dataset: {len(df)} rows")
    
    if len(df) < 100:
        print("\nERROR: Not enough data!")
        return
    
    # Prepare data
    X = df[enhanced_features].values
    y = df[target_cols].values
    
    # Train-test split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )
    
    print(f"\n{'='*70}")
    print(f"Dataset Split:")
    print(f"  Training: {len(X_train)} samples")
    print(f"  Testing:  {len(X_test)} samples")
    print(f"  Features: {len(enhanced_features)} (original had {len(original_features)})")
    print(f"  Targets:  {len(target_cols)}")
    print(f"{'='*70}")
    
    # Scale features
    print("\nScaling features...")
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    # ENHANCED XGBOOST CONFIGURATION
    print("\nTraining Enhanced XGBoost model...")
    print("\nConfiguration:")
    print("  - n_estimators: 300 (increased from 200)")
    print("  - max_depth: 8 (increased from 6)")
    print("  - learning_rate: 0.03 (decreased for stability)")
    print("  - subsample: 0.85")
    print("  - colsample_bytree: 0.85")
    print("  - reg_alpha: 0.1 (L1 regularization)")
    print("  - reg_lambda: 1.0 (L2 regularization)")
    
    base_model = xgb.XGBRegressor(
        n_estimators=300,           # More trees
        max_depth=8,                # Deeper trees for interactions
        learning_rate=0.03,         # Slower learning for stability
        subsample=0.85,             # 85% data per tree
        colsample_bytree=0.85,      # 85% features per tree
        reg_alpha=0.1,              # L1 regularization
        reg_lambda=1.0,             # L2 regularization
        min_child_weight=3,         # Prevent overfitting
        gamma=0.1,                  # Min loss reduction
        random_state=42,
        n_jobs=-1,
        verbosity=0
    )
    
    if len(target_cols) > 1:
        model = MultiOutputRegressor(base_model)
    else:
        model = base_model
    
    print("\nTraining in progress...")
    model.fit(X_train_scaled, y_train)
    print("✓ Training complete!")
    
    # Evaluate on test set
    print("\n" + "="*70)
    print("MODEL PERFORMANCE ON TEST SET")
    print("="*70)
    
    y_pred = model.predict(X_test_scaled)
    
    if len(target_cols) > 1:
        r2_scores = r2_score(y_test, y_pred, multioutput='raw_values')
        mae_scores = mean_absolute_error(y_test, y_pred, multioutput='raw_values')
        rmse_scores = np.sqrt(mean_squared_error(y_test, y_pred, multioutput='raw_values'))
    else:
        r2_scores = [r2_score(y_test, y_pred)]
        mae_scores = [mean_absolute_error(y_test, y_pred)]
        rmse_scores = [np.sqrt(mean_squared_error(y_test, y_pred))]
    
    for i, col in enumerate(target_cols):
        print(f"\n{col}:")
        print(f"  R² Score:  {r2_scores[i]:.4f}")
        print(f"  MAE:       {mae_scores[i]:.4f}")
        print(f"  RMSE:      {rmse_scores[i]:.4f}")
    
    avg_r2 = np.mean(r2_scores)
    print(f"\n{'='*70}")
    print(f"Average R² Score: {avg_r2:.4f}")
    
    if avg_r2 > 0.95:
        print("🎉 EXCELLENT! Model performance is outstanding!")
    elif avg_r2 > 0.90:
        print("✓ GOOD! Model performance is strong!")
    else:
        print("○ Model trained, but performance could be improved.")
    
    print(f"{'='*70}")
    
    # Cross-validation for robustness check
    print("\nPerforming 5-fold cross-validation...")
    cv_scores = []
    for i, target in enumerate(target_cols):
        if len(target_cols) > 1:
            single_model = xgb.XGBRegressor(
                n_estimators=300, max_depth=8, learning_rate=0.03,
                subsample=0.85, colsample_bytree=0.85,
                reg_alpha=0.1, reg_lambda=1.0,
                random_state=42, n_jobs=-1, verbosity=0
            )
            scores = cross_val_score(single_model, X_train_scaled, y_train[:, i], 
                                   cv=5, scoring='r2', n_jobs=-1)
        else:
            scores = cross_val_score(base_model, X_train_scaled, y_train, 
                                   cv=5, scoring='r2', n_jobs=-1)
        cv_scores.append(scores.mean())
        print(f"  {target}: {scores.mean():.4f} (±{scores.std():.4f})")
    
    # Save model
    os.makedirs(MODEL_DIR, exist_ok=True)
    joblib.dump(model, f"{MODEL_DIR}/propulsion_model_enhanced.pkl")
    joblib.dump(scaler, f"{MODEL_DIR}/feature_scaler_enhanced.pkl")
    joblib.dump(enhanced_features, f"{MODEL_DIR}/feature_columns_enhanced.pkl")
    joblib.dump(target_cols, f"{MODEL_DIR}/target_columns_enhanced.pkl")
    
    print(f"\n{'='*70}")
    print("✓ ENHANCED MODEL SAVED!")
    print(f"{'='*70}")
    print(f"Location: {MODEL_DIR}/")
    print("Files:")
    print("  - propulsion_model_enhanced.pkl")
    print("  - feature_scaler_enhanced.pkl")
    print("  - feature_columns_enhanced.pkl")
    print("  - target_columns_enhanced.pkl")
    
    # Compare with original
    print(f"\n{'='*70}")
    print("COMPARISON WITH ORIGINAL MODEL")
    print(f"{'='*70}")
    print(f"Original features:  {len(original_features)}")
    print(f"Enhanced features:  {len(enhanced_features)}")
    print(f"Improvement:        +{len(enhanced_features) - len(original_features)} physics-based features")
    print(f"\nExpected improvement: 1-3% increase in R² score")
    print(f"More stable predictions for edge cases")
    print(f"Better physics consistency")
    
    print(f"\n{'='*70}")
    print("NEXT STEPS")
    print(f"{'='*70}")
    print("1. Compare with original model using src/compare_models.py")
    print("2. Generate predictions with enhanced features")
    print("3. Update web app to use enhanced model")

if __name__ == "__main__":
    main()
