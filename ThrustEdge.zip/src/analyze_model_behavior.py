import joblib
import numpy as np

MODEL_DIR = "models"

# Load model
model = joblib.load(f"{MODEL_DIR}/propulsion_model.pkl")
scaler = joblib.load(f"{MODEL_DIR}/feature_scaler.pkl")

print("="*70)
print("TESTING MODEL BEHAVIOR AT LOW THROTTLE")
print("="*70)

# Test 1: Known good combo
print("\nTest 1: 2850 Kv, 7x6 prop, 30A, 11.1V at LOW throttle")
for throttle in [1000, 1050, 1100, 1150, 1200]:
    X = np.array([[2850, 7.0, 6.0, 30, throttle, 11.1]])
    X_scaled = scaler.transform(X)
    pred = model.predict(X_scaled)[0]
    print(f"  Throttle {throttle}: RPM={pred[0]:.1f}, Thrust={pred[1]:.4f}, Power={pred[2]:.2f}")

# Test 2: The problematic combo
print("\nTest 2: 1000 Kv, 10x4.5 prop, 30A, 11.1V at LOW throttle")
for throttle in [1000, 1050, 1100, 1150, 1200]:
    X = np.array([[1000, 10.0, 4.5, 30, throttle, 11.1]])
    X_scaled = scaler.transform(X)
    pred = model.predict(X_scaled)[0]
    print(f"  Throttle {throttle}: RPM={pred[0]:.1f}, Thrust={pred[1]:.4f}, Power={pred[2]:.2f}")

# Test 3: Closest known combo
print("\nTest 3: 910 Kv, 10x4.75 prop, 30A, 11.1V at LOW throttle")
for throttle in [1000, 1050, 1100, 1150, 1200]:
    X = np.array([[910, 10.0, 4.75, 30, throttle, 11.1]])
    X_scaled = scaler.transform(X)
    pred = model.predict(X_scaled)[0]
    print(f"  Throttle {throttle}: RPM={pred[0]:.1f}, Thrust={pred[1]:.4f}, Power={pred[2]:.2f}")

print("\n" + "="*70)
