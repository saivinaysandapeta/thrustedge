import joblib
import numpy as np
import pandas as pd
import os

class PhysicsInformedPredictor:
    """
    Complete physics-decomposed prediction system
    
    Combines:
    - Model A: Aerodynamic (C_T, C_P from prop geometry)
    - Model B: Motor/Electrical (RPM, Current from Kv, V, throttle)
    - Physics equations: Enforce energy conservation
    """
    
    def __init__(self, models_dir="models"):
        self.AIR_DENSITY = 1.225
        self.g = 9.81
        self.kinematic_viscosity = 1.5e-5
        
        print("Loading physics-informed models...")
        
        # Load Model A (Aerodynamic)
        self.model_ct = joblib.load(f"{models_dir}/aero_model_ct.pkl")
        self.model_cp = joblib.load(f"{models_dir}/aero_model_cp.pkl")
        self.scaler_aero = joblib.load(f"{models_dir}/aero_scaler.pkl")
        self.aero_features = joblib.load(f"{models_dir}/aero_features.pkl")
        
        # Load Model B (Motor)
        self.model_rpm = joblib.load(f"{models_dir}/motor_model_rpm.pkl")
        self.model_current = joblib.load(f"{models_dir}/motor_model_current.pkl")
        self.scaler_motor = joblib.load(f"{models_dir}/motor_scaler.pkl")
        self.motor_features = joblib.load(f"{models_dir}/motor_features.pkl")
        
        print("✓ All models loaded successfully")
    
    def inch_to_meter(self, inches):
        return inches * 0.0254
    
    def calculate_reynolds(self, tip_speed_ms, diameter_inch):
        D = self.inch_to_meter(diameter_inch)
        return tip_speed_ms * D / self.kinematic_viscosity
    
    def predict_single_point(self, motor_kv, prop_d, prop_p, esc_limit, throttle_us, voltage):
        """
        Predict single operating point using physics-decomposed models
        
        Returns: dict with RPM, Thrust, Current, Power, Efficiency, etc.
        """
        
        throttle_pct = (throttle_us - 1000) / 1000
        
        # Handle very low throttle
        if throttle_us < 1100:
            return {
                'Throttle_us': throttle_us,
                'RPM': 0,
                'Thrust_kgf': 0,
                'Current_A': 0,
                'Voltage_V': voltage,
                'ElecPower_W': 0,
                'MechPower_W': 0,
                'Efficiency_gf_per_W': 0,
                'C_T': 0,
                'C_P': 0
            }
        
        # STEP 1: Predict RPM and Current using Model B (Motor)
        motor_features = pd.DataFrame({
            'Motor_Kv': [motor_kv],
            'Voltage_V': [voltage],
            'ESC_limit_A': [esc_limit],
            'Throttle_pct': [throttle_pct],
            'Prop_D_inch': [prop_d],
            'Prop_P_inch': [prop_p],
            'Prop_load': [prop_d ** 2 * prop_p]
        })
        
        motor_features_scaled = self.scaler_motor.transform(motor_features)
        
        rpm = self.model_rpm.predict(motor_features_scaled)[0]
        current = self.model_current.predict(motor_features_scaled)[0]
        
        # Ensure non-negative
        rpm = max(0, rpm)
        current = max(0, current)
        
        # STEP 2: Calculate tip speed and Reynolds
        tip_speed = (rpm / 60) * np.pi * self.inch_to_meter(prop_d)
        reynolds = self.calculate_reynolds(tip_speed, prop_d)
        
        # STEP 3: Predict C_T and C_P using Model A (Aerodynamic)
        aero_features = pd.DataFrame({
		'Prop_D_inch': [prop_d],
    		'Prop_P_inch': [prop_p],
    		'Pitch_Ratio': [prop_p / prop_d],
    		'RPM': [rpm],
    		'RPM_squared': [rpm ** 2],
    		'Tip_Speed_ms': [tip_speed],
    		'Tip_Speed_squared': [tip_speed ** 2],
    		'Reynolds': [np.log10(reynolds + 1)],
    		'Low_RPM_flag': [1.0 if rpm < 10000 else 0.0],
        })
        
        aero_features_scaled = self.scaler_aero.transform(aero_features)
        
        C_T = self.model_ct.predict(aero_features_scaled)[0]
        C_P = self.model_cp.predict(aero_features_scaled)[0]
        
        # Clip to physical bounds
        C_T = np.clip(C_T, 0.001, 0.5)
        C_P = np.clip(C_P, 0.001, 0.5)
        
        # STEP 4: Calculate thrust and mechanical power from coefficients
        D = self.inch_to_meter(prop_d)
        n = rpm / 60  # rev/s
        
        # Thrust from C_T
        thrust_N = C_T * self.AIR_DENSITY * (n ** 2) * (D ** 4)
        thrust_kgf = thrust_N / self.g
        
        # Mechanical power from C_P
        mech_power = C_P * self.AIR_DENSITY * (n ** 3) * (D ** 5)
        
        # STEP 5: Calculate electrical power (physics constraint)
        elec_power = voltage * current
        
        # STEP 6: Calculate efficiency
        efficiency_gf_per_w = (thrust_kgf * 1000) / (elec_power + 0.1)
        
        return {
            'Throttle_us': int(throttle_us),
            'RPM': round(rpm, 1),
            'Thrust_kgf': round(thrust_kgf, 6),
            'Current_A': round(current, 3),
            'Voltage_V': round(voltage, 2),
            'ElecPower_W': round(elec_power, 2),
            'MechPower_W': round(mech_power, 2),
            'Efficiency_gf_per_W': round(efficiency_gf_per_w, 3),
            'C_T': round(C_T, 6),
            'C_P': round(C_P, 6)
        }
    
    def generate_csv(self, motor_kv, prop_d, prop_p, esc_limit, voltage,
                     throttle_start=1000, throttle_end=2000, throttle_step=50,
                     output_dir="predictions"):
        """
        Generate complete performance CSV for given configuration
        """
        
        print("="*70)
        print("PHYSICS-INFORMED CSV GENERATION")
        print("="*70)
        
        print(f"\nConfiguration:")
        print(f"  Motor Kv:       {motor_kv}")
        print(f"  Propeller:      {prop_d}x{prop_p} inches")
        print(f"  ESC:            {esc_limit}A")
        print(f"  Voltage:        {voltage}V")
        print(f"  Throttle range: {throttle_start}-{throttle_end} µs (step {throttle_step})")
        
        # Generate predictions
        throttle_points = range(throttle_start, throttle_end + 1, throttle_step)
        results = []
        
        for throttle in throttle_points:
            result = self.predict_single_point(
                motor_kv, prop_d, prop_p, esc_limit, throttle, voltage
            )
            results.append(result)
        
        # Convert to DataFrame
        df = pd.DataFrame(results)
        
        # Add configuration columns
        df.insert(0, 'Motor_Kv', motor_kv)
        df.insert(1, 'Prop_D_inch', prop_d)
        df.insert(2, 'Prop_P_inch', prop_p)
        df.insert(3, 'ESC_limit_A', esc_limit)
        
        # Display sample
        print("\n" + "="*70)
        print("SAMPLE PREDICTIONS")
        print("="*70)
        print(df[['Throttle_us', 'RPM', 'Thrust_kgf', 'Current_A', 
                  'ElecPower_W', 'Efficiency_gf_per_W']].head(10))
        
        # Summary
        print("\n" + "="*70)
        print("PERFORMANCE SUMMARY")
        print("="*70)
        print(f"  Max RPM:         {df['RPM'].max():.0f}")
        print(f"  Max Thrust:      {df['Thrust_kgf'].max():.3f} kgf ({df['Thrust_kgf'].max()*1000:.1f} gf)")
        print(f"  Max Current:     {df['Current_A'].max():.2f} A")
        print(f"  Max Power:       {df['ElecPower_W'].max():.1f} W")
        print(f"  Best Efficiency: {df['Efficiency_gf_per_W'].max():.2f} gf/W")
        
        # Save
        os.makedirs(output_dir, exist_ok=True)
        filename = f"{output_dir}/physics_pred_{int(motor_kv)}kv_{prop_d}x{prop_p}_{voltage}v.csv"
        df.to_csv(filename, index=False)
        
        print(f"\n✓ Saved to: {filename}")
        print("="*70)
        
        return df


if __name__ == "__main__":
    predictor = PhysicsInformedPredictor()
    
    # Example 1: Test with known config (1700 Kv, 7x4)
    print("\nExample 1: 1700 Kv, 7x4 prop, 50A ESC, 12.6V")
    df1 = predictor.generate_csv(
        motor_kv=1700,
        prop_d=7.0,
        prop_p=4.0,
        esc_limit=50,
        voltage=12.6
    )
    
    # Example 2: Unknown combo (for validation)
    print("\n" + "="*70)
    print("\nExample 2: 2850 Kv, 7x6 prop, 30A ESC, 11.1V")
    df2 = predictor.generate_csv(
        motor_kv=2850,
        prop_d=7.0,
        prop_p=6.0,
        esc_limit=30,
        voltage=11.1
    )
