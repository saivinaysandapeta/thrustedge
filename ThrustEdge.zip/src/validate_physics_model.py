import pandas as pd
import numpy as np

# Load actual experimental data
actual = pd.read_excel('data/raw/216.xlsx')

# Load physics prediction
predicted = pd.read_csv('predictions/physics_pred_1700kv_7.0x4.0_12.6v.csv')

print("="*70)
print("VALIDATION: PHYSICS MODEL vs ACTUAL THRUST STAND DATA")
print("="*70)

# Check actual column names
print("\nActual data columns:")
print(actual.columns.tolist())

# Clean column names (remove special characters)
actual.columns = actual.columns.str.strip()

print("\nActual data (216.xlsx - 1700 Kv, 7x4, 12.6V):")
print(actual.head(10))

print("\nPhysics predictions:")
print(predicted[['Throttle_us', 'RPM', 'Thrust_kgf', 'ElecPower_W']].head(10))

# Map column names
throttle_col = 'Throttle (Âµs)'  # or find correct name
rpm_col = 'Rotation speed (rpm)'
thrust_col = 'Thrust (kgf)'
power_col = 'Electrical power (W)'

# Find correct column names dynamically
for col in actual.columns:
    if 'throttle' in col.lower():
        throttle_col = col
    if 'rotation' in col.lower() or 'rpm' in col.lower():
        rpm_col = col
    if 'thrust' in col.lower():
        thrust_col = col
    if 'electrical power' in col.lower() or 'power' in col.lower():
        power_col = col

print(f"\nUsing columns:")
print(f"  Throttle: {throttle_col}")
print(f"  RPM: {rpm_col}")
print(f"  Thrust: {thrust_col}")
print(f"  Power: {power_col}")

# Compare at specific throttle points
print("\n" + "="*70)
print("POINT-BY-POINT COMPARISON")
print("="*70)

throttles_to_compare = [1200, 1250, 1300, 1350, 1400, 1500, 1600, 1700]

print(f"\n{'Throttle':<10} {'Metric':<15} {'Actual':<12} {'Predicted':<12} {'Error':<10}")
print("-"*70)

for throttle in throttles_to_compare:
    # Find closest match in actual data
    actual_row = actual[actual[throttle_col] == throttle]
    pred_row = predicted[predicted['Throttle_us'] == throttle]
    
    if not actual_row.empty and not pred_row.empty:
        # RPM comparison
        actual_rpm = actual_row[rpm_col].values[0]
        pred_rpm = pred_row['RPM'].values[0]
        
        if actual_rpm > 0:
            rpm_error = abs(actual_rpm - pred_rpm) / actual_rpm * 100
            print(f"{throttle:<10} {'RPM':<15} {actual_rpm:<12.0f} {pred_rpm:<12.0f} {rpm_error:<10.1f}%")
        
        # Thrust comparison
        actual_thrust = actual_row[thrust_col].values[0]
        pred_thrust = pred_row['Thrust_kgf'].values[0]
        
        if actual_thrust > 0:
            thrust_error = abs(actual_thrust - pred_thrust) / actual_thrust * 100
            print(f"{'':<10} {'Thrust (kgf)':<15} {actual_thrust:<12.4f} {pred_thrust:<12.4f} {thrust_error:<10.1f}%")
        
        # Power comparison
        actual_power = actual_row[power_col].values[0]
        pred_power = pred_row['ElecPower_W'].values[0]
        
        if actual_power > 0:
            power_error = abs(actual_power - pred_power) / actual_power * 100
            print(f"{'':<10} {'Power (W)':<15} {actual_power:<12.2f} {pred_power:<12.2f} {power_error:<10.1f}%")
        
        print("-"*70)

print("\n" + "="*70)
print("SUMMARY STATISTICS")
print("="*70)

# Calculate overall errors
rpm_errors = []
thrust_errors = []
power_errors = []

for throttle in throttles_to_compare:
    actual_row = actual[actual[throttle_col] == throttle]
    pred_row = predicted[predicted['Throttle_us'] == throttle]
    
    if not actual_row.empty and not pred_row.empty:
        actual_rpm = actual_row[rpm_col].values[0]
        pred_rpm = pred_row['RPM'].values[0]
        
        actual_thrust = actual_row[thrust_col].values[0]
        pred_thrust = pred_row['Thrust_kgf'].values[0]
        
        actual_power = actual_row[power_col].values[0]
        pred_power = pred_row['ElecPower_W'].values[0]
        
        if actual_rpm > 0:
            rpm_errors.append(abs(actual_rpm - pred_rpm) / actual_rpm * 100)
        if actual_thrust > 0:
            thrust_errors.append(abs(actual_thrust - pred_thrust) / actual_thrust * 100)
        if actual_power > 0:
            power_errors.append(abs(actual_power - pred_power) / actual_power * 100)

if rpm_errors:
    print(f"\nMean Absolute Percentage Error (MAPE):")
    print(f"  RPM:    {np.mean(rpm_errors):.2f}%")
    print(f"  Thrust: {np.mean(thrust_errors):.2f}%")
    print(f"  Power:  {np.mean(power_errors):.2f}%")
    
    print(f"\nMax errors:")
    print(f"  RPM:    {np.max(rpm_errors):.2f}%")
    print(f"  Thrust: {np.max(thrust_errors):.2f}%")
    print(f"  Power:  {np.max(power_errors):.2f}%")

print("\n" + "="*70)
print("✓ Validation complete!")
print("="*70)
