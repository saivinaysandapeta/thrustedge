import pandas as pd

# Load your data
df = pd.read_csv("data/processed/train_dataset.csv")

# Search for similar configuration
target_config = {
    'Motor_Kv': 2850,
    'Prop_D_inch': 7.0,
    'Prop_P_inch': 6.0,
    'ESC_limit_A': 30,
    'Throttle_us': 1500,
    'Voltage_V': 11.1
}

print("="*70)
print("SEARCHING FOR ACTUAL TEST DATA")
print("="*70)
print(f"\nTarget: {target_config}")

# Find close matches
tolerance = {
    'Motor_Kv': 50,
    'Prop_D_inch': 0.2,
    'Prop_P_inch': 0.2,
    'ESC_limit_A': 5,
    'Throttle_us': 100,
    'Voltage_V': 0.5
}

mask = (
    (df['Motor_Kv'] >= target_config['Motor_Kv'] - tolerance['Motor_Kv']) &
    (df['Motor_Kv'] <= target_config['Motor_Kv'] + tolerance['Motor_Kv']) &
    (df['Prop_D_inch'] >= target_config['Prop_D_inch'] - tolerance['Prop_D_inch']) &
    (df['Prop_D_inch'] <= target_config['Prop_D_inch'] + tolerance['Prop_D_inch']) &
    (df['Prop_P_inch'] >= target_config['Prop_P_inch'] - tolerance['Prop_P_inch']) &
    (df['Prop_P_inch'] <= target_config['Prop_P_inch'] + tolerance['Prop_P_inch']) &
    (df['Throttle_us'] >= target_config['Throttle_us'] - tolerance['Throttle_us']) &
    (df['Throttle_us'] <= target_config['Throttle_us'] + tolerance['Throttle_us']) &
    (df['Voltage_V'] >= target_config['Voltage_V'] - tolerance['Voltage_V']) &
    (df['Voltage_V'] <= target_config['Voltage_V'] + tolerance['Voltage_V'])
)

matches = df[mask]

if len(matches) > 0:
    print(f"\n✓ Found {len(matches)} similar configurations!\n")
    
    print(f"{'Kv':<6} {'D':<6} {'P':<6} {'ESC':<6} {'Throttle':<10} {'Voltage':<8} {'RPM':<8} {'Thrust':<10} {'Power':<8}")
    print("-"*80)
    
    for idx, row in matches.iterrows():
        print(f"{row['Motor_Kv']:<6.0f} {row['Prop_D_inch']:<6.1f} {row['Prop_P_inch']:<6.1f} "
              f"{row['ESC_limit_A']:<6.0f} {row['Throttle_us']:<10.0f} {row['Voltage_V']:<8.2f} "
              f"{row['RPM']:<8.0f} {row['Thrust_kgf']:<10.3f} {row['ElecPower_W']:<8.1f}")
    
    print("\n" + "="*70)
    print("AVERAGE ACTUAL VALUES")
    print("="*70)
    avg_rpm = matches['RPM'].mean()
    avg_thrust = matches['Thrust_kgf'].mean()
    avg_power = matches['ElecPower_W'].mean()
    
    print(f"Average RPM:    {avg_rpm:.0f}")
    print(f"Average Thrust: {avg_thrust:.3f} kgf")
    print(f"Average Power:  {avg_power:.1f} W")
    
    print("\n" + "="*70)
    print("COMPARISON WITH MODEL PREDICTIONS")
    print("="*70)
    
    # Model predictions from previous output
    original_rpm = 9600.62
    original_thrust = 0.19
    original_power = 58.28
    
    enhanced_rpm = 11371.11
    enhanced_thrust = 0.23
    enhanced_power = 76.64
    
    print(f"\n{'Metric':<15} {'Actual':<12} {'Original':<12} {'Enhanced':<12} {'Winner':<10}")
    print("-"*70)
    
    # RPM comparison
    orig_rpm_err = abs(avg_rpm - original_rpm)
    enh_rpm_err = abs(avg_rpm - enhanced_rpm)
    rpm_winner = "Original" if orig_rpm_err < enh_rpm_err else "Enhanced"
    print(f"{'RPM':<15} {avg_rpm:<12.0f} {original_rpm:<12.0f} {enhanced_rpm:<12.0f} {rpm_winner:<10}")
    print(f"{'  Error':<15} {'':<12} {orig_rpm_err:<12.0f} {enh_rpm_err:<12.0f}")
    
    # Thrust comparison
    orig_thrust_err = abs(avg_thrust - original_thrust)
    enh_thrust_err = abs(avg_thrust - enhanced_thrust)
    thrust_winner = "Original" if orig_thrust_err < enh_thrust_err else "Enhanced"
    print(f"{'Thrust (kgf)':<15} {avg_thrust:<12.3f} {original_thrust:<12.3f} {enhanced_thrust:<12.3f} {thrust_winner:<10}")
    print(f"{'  Error':<15} {'':<12} {orig_thrust_err:<12.3f} {enh_thrust_err:<12.3f}")
    
    # Power comparison
    orig_power_err = abs(avg_power - original_power)
    enh_power_err = abs(avg_power - enhanced_power)
    power_winner = "Original" if orig_power_err < enh_power_err else "Enhanced"
    print(f"{'Power (W)':<15} {avg_power:<12.1f} {original_power:<12.1f} {enhanced_power:<12.1f} {power_winner:<10}")
    print(f"{'  Error':<15} {'':<12} {orig_power_err:<12.1f} {enh_power_err:<12.1f}")
    
else:
    print("\n✗ No exact matches found in dataset.")
    print("Widening search...")
    
    # Widen search - just match motor and prop
    mask_wide = (
        (df['Motor_Kv'] == target_config['Motor_Kv']) &
        (df['Prop_D_inch'] == target_config['Prop_D_inch']) &
        (df['Prop_P_inch'] == target_config['Prop_P_inch'])
    )
    
    matches_wide = df[mask_wide]
    
    if len(matches_wide) > 0:
        print(f"\nFound {len(matches_wide)} configs with same motor/prop")
        print("\nSample data at various throttle settings:")
        print(f"{'Throttle':<10} {'Voltage':<8} {'RPM':<8} {'Thrust':<10} {'Power':<8}")
        print("-"*60)
        
        for idx, row in matches_wide.head(10).iterrows():
            print(f"{row['Throttle_us']:<10.0f} {row['Voltage_V']:<8.2f} "
                  f"{row['RPM']:<8.0f} {row['Thrust_kgf']:<10.3f} {row['ElecPower_W']:<8.1f}")
    else:
        print("\nNo data found for this motor/prop combination.")
        print("Models are extrapolating - use predictions with caution!")

print("\n" + "="*70)
