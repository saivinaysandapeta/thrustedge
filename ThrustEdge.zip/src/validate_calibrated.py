import pandas as pd
import numpy as np

# Load actual experimental data
actual = pd.read_excel('data/raw/216.xlsx')

# Load CALIBRATED prediction
predicted = pd.read_csv('predictions/calibrated_pred_1700kv_7.0x4.0_12.6v.csv')

print("="*70)
print("VALIDATION: CALIBRATED MODEL vs ACTUAL DATA")
print("="*70)

# Find column names
throttle_col = [c for c in actual.columns if 'throttle' in c.lower()][0]
rpm_col = [c for c in actual.columns if 'rotation' in c.lower() or 'rpm' in c.lower()][0]
thrust_col = [c for c in actual.columns if 'thrust' in c.lower()][0]
power_col = [c for c in actual.columns if 'electrical power' in c.lower()][0]

print(f"\n{'Throttle':<10} {'Metric':<15} {'Actual':<12} {'Predicted':<12} {'Error':<10} {'Status':<10}")
print("="*70)

throttles = [1200, 1250, 1300, 1350, 1400, 1500, 1600, 1700]

rpm_errors = []
thrust_errors = []
power_errors = []

for throttle in throttles:
    actual_row = actual[actual[throttle_col] == throttle]
    pred_row = predicted[predicted['Throttle_us'] == throttle]
    
    if not actual_row.empty and not pred_row.empty:
        # RPM
        actual_rpm = actual_row[rpm_col].values[0]
        pred_rpm = pred_row['RPM'].values[0]
        rpm_err = abs(actual_rpm - pred_rpm) / actual_rpm * 100
        rpm_errors.append(rpm_err)
        status = "✓" if rpm_err < 15 else "⚠"
        print(f"{throttle:<10} {'RPM':<15} {actual_rpm:<12.0f} {pred_rpm:<12.0f} {rpm_err:<10.1f}% {status:<10}")
        
        # Thrust
        actual_thrust = actual_row[thrust_col].values[0]
        pred_thrust = pred_row['Thrust_kgf'].values[0]
        thrust_err = abs(actual_thrust - pred_thrust) / actual_thrust * 100
        thrust_errors.append(thrust_err)
        status = "✓✓" if thrust_err < 10 else ("✓" if thrust_err < 20 else "⚠")
        print(f"{'':<10} {'Thrust (kgf)':<15} {actual_thrust:<12.4f} {pred_thrust:<12.4f} {thrust_err:<10.1f}% {status:<10}")
        
        # Power
        actual_power = actual_row[power_col].values[0]
        pred_power = pred_row['ElecPower_W'].values[0]
        power_err = abs(actual_power - pred_power) / actual_power * 100
        power_errors.append(power_err)
        status = "✓" if power_err < 20 else "⚠"
        print(f"{'':<10} {'Power (W)':<15} {actual_power:<12.2f} {pred_power:<12.2f} {power_err:<10.1f}% {status:<10}")
        print("-"*70)

print("\n" + "="*70)
print("SUMMARY STATISTICS")
print("="*70)

print(f"\nMean Absolute Percentage Error (MAPE):")
print(f"  RPM:    {np.mean(rpm_errors):.2f}% {'✓ Excellent' if np.mean(rpm_errors) < 10 else '✓ Good'}")
print(f"  Thrust: {np.mean(thrust_errors):.2f}% {'✓✓ Excellent' if np.mean(thrust_errors) < 15 else ('✓ Good' if np.mean(thrust_errors) < 25 else '⚠ Fair')}")
print(f"  Power:  {np.mean(power_errors):.2f}% {'✓ Excellent' if np.mean(power_errors) < 15 else ('✓ Good' if np.mean(power_errors) < 25 else '⚠ Fair')}")

print(f"\nMax errors:")
print(f"  RPM:    {np.max(rpm_errors):.2f}%")
print(f"  Thrust: {np.max(thrust_errors):.2f}%")
print(f"  Power:  {np.max(power_errors):.2f}%")

print("\n" + "="*70)
print("IMPROVEMENT vs UNCALIBRATED MODEL")
print("="*70)
print(f"Previous thrust MAPE: 106.23%")
print(f"Calibrated thrust MAPE: {np.mean(thrust_errors):.2f}%")
print(f"Improvement: {106.23 - np.mean(thrust_errors):.1f} percentage points")
print("\n✓ Calibration successful!")
print("="*70)
