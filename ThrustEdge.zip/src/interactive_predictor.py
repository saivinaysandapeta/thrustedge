import joblib
import numpy as np
import pandas as pd
import os

class UniversalThrustPredictor:
    """Interactive thrust prediction using auto-calibrated props"""
    
    def __init__(self):
        self.AIR_DENSITY = 1.225
        self.g = 9.81
        
        # Load calibrations
        cal_path = "models/calibrations/calibration_index.pkl"
        if os.path.exists(cal_path):
            self.calibrations = joblib.load(cal_path)
            print(f"✓ Loaded {len(self.calibrations)} calibrated props")
        else:
            print("⚠ No calibration file found!")
            self.calibrations = {}
    
    def list_available_props(self):
        """Display all calibrated prop sizes"""
        print("\n" + "="*70)
        print("AVAILABLE CALIBRATED PROPS")
        print("="*70)
        
        props_by_diameter = {}
        for prop_key in sorted(self.calibrations.keys()):
            cal = self.calibrations[prop_key]
            diameter = cal['prop_diameter']
            if diameter not in props_by_diameter:
                props_by_diameter[diameter] = []
            props_by_diameter[diameter].append(prop_key)
        
        for diameter in sorted(props_by_diameter.keys()):
            props = props_by_diameter[diameter]
            print(f"\n{diameter:.1f}\" diameter: {', '.join(props)}")
        
        print("\n" + "="*70)
    
    def get_calibration_info(self, prop_d, prop_p):
        """Get detailed calibration info for a prop"""
        prop_key = f"{prop_d:.1f}x{prop_p:.1f}"
        
        if prop_key not in self.calibrations:
            return None
        
        cal = self.calibrations[prop_key]
        
        info = f"""
Calibration Info for {prop_key}:
  Data Points: {cal['data_points']}
  RPM Range: {cal['rpm_range'][0]:.0f} - {cal['rpm_range'][1]:.0f}
  C_T Range: {cal['ct_range'][0]:.4f} - {cal['ct_range'][1]:.4f}
  C_T MAPE: {cal['ct_mape']:.2f}%
  C_P Available: {'Yes' if cal['cp_mape'] else 'No'}
  Source: {cal['source_file']}
"""
        return info
    
    def ct_model(self, rpm, a, b, c):
        """Parametric C_T model"""
        return a + b * np.log(rpm + 1) + c * rpm / 10000
    
    def cp_model(self, rpm, a, b, c):
        """Parametric C_P model"""
        return a + b * np.log(rpm + 1) + c * rpm / 10000
    
    def predict(self, motor_kv, voltage, prop_d, prop_p, throttle_percent):
        """
        Predict thrust and power for given configuration
        
        Parameters:
        -----------
        motor_kv : float
            Motor KV rating
        voltage : float
            Battery voltage (V)
        prop_d : float
            Propeller diameter (inches)
        prop_p : float
            Propeller pitch (inches)
        throttle_percent : float
            Throttle percentage (0-100)
        
        Returns:
        --------
        dict : Prediction results
        """
        
        prop_key = f"{prop_d:.1f}x{prop_p:.1f}"
        
        # Check if calibration exists
        if prop_key not in self.calibrations:
            print(f"\n⚠ No calibration available for {prop_key}")
            print("\nClosest available props:")
            
            # Find closest props
            available_sizes = []
            for key in self.calibrations.keys():
                d, p = map(float, key.split('x'))
                diff = abs(d - prop_d) + abs(p - prop_p)
                available_sizes.append((diff, key))
            
            for _, key in sorted(available_sizes)[:5]:
                print(f"  - {key}")
            
            return None
        
        cal = self.calibrations[prop_key]
        
        # Calculate RPM
        rpm = motor_kv * voltage * (throttle_percent / 100)
        
        # Check if RPM is within calibration range
        rpm_min, rpm_max = cal['rpm_range']
        if rpm < rpm_min * 0.8 or rpm > rpm_max * 1.2:
            print(f"⚠ Warning: RPM {rpm:.0f} outside calibration range [{rpm_min:.0f}, {rpm_max:.0f}]")
        
        # Calculate C_T
        ct_params = cal['ct_params']
        ct = self.ct_model(rpm, *ct_params)
        
        # Calculate thrust
        D = prop_d * 0.0254  # Convert to meters
        n = rpm / 60  # Convert to Hz
        
        thrust_N = ct * self.AIR_DENSITY * (n ** 2) * (D ** 4)
        thrust_kgf = thrust_N / self.g
        thrust_lbf = thrust_kgf * 2.20462
        
        # Calculate power (if C_P available)
        power_W = None
        power_A = None
        efficiency = None
        
        if cal['cp_params']:
            cp_params = cal['cp_params']
            cp = self.cp_model(rpm, *cp_params)
            
            power_W = cp * self.AIR_DENSITY * (n ** 3) * (D ** 5)
            power_A = power_W / voltage
            
            # Mechanical efficiency
            efficiency = (thrust_N * (n * D)) / (power_W + 1e-6) if power_W > 0 else 0
        
        result = {
            'configuration': f"{motor_kv}KV @ {voltage}V with {prop_key} @ {throttle_percent}%",
            'rpm': rpm,
            'ct': ct,
            'thrust_N': thrust_N,
            'thrust_kgf': thrust_kgf,
            'thrust_lbf': thrust_lbf,
            'power_W': power_W,
            'current_A': power_A,
            'efficiency': efficiency,
            'calibration_mape': cal['ct_mape'],
            'rpm_range': cal['rpm_range']
        }
        
        return result
    
    def predict_throttle_sweep(self, motor_kv, voltage, prop_d, prop_p, 
                               throttle_range=(0, 100, 10)):
        """
        Predict performance across throttle range
        
        Parameters:
        -----------
        throttle_range : tuple
            (start, stop, step) for throttle sweep
        """
        
        start, stop, step = throttle_range
        throttles = np.arange(start, stop + step, step)
        
        results = []
        for throttle in throttles:
            if throttle == 0:
                continue
            
            pred = self.predict(motor_kv, voltage, prop_d, prop_p, throttle)
            if pred:
                results.append({
                    'throttle_%': throttle,
                    'rpm': pred['rpm'],
                    'thrust_kgf': pred['thrust_kgf'],
                    'power_W': pred['power_W'],
                    'current_A': pred['current_A']
                })
        
        return pd.DataFrame(results)
    
    def print_prediction(self, result):
        """Pretty print prediction result"""
        
        if result is None:
            return
        
        print("\n" + "="*70)
        print("THRUST PREDICTION")
        print("="*70)
        print(f"\nConfiguration: {result['configuration']}")
        print(f"Calibration Accuracy: {result['calibration_mape']:.2f}% MAPE")
        print(f"RPM Range (calibrated): {result['rpm_range'][0]:.0f} - {result['rpm_range'][1]:.0f}")
        
        print("\n--- Performance ---")
        print(f"  RPM:       {result['rpm']:.0f}")
        print(f"  Thrust:    {result['thrust_kgf']:.3f} kgf ({result['thrust_N']:.2f} N, {result['thrust_lbf']:.3f} lbf)")
        print(f"  C_T:       {result['ct']:.4f}")
        
        if result['power_W']:
            print(f"\n--- Power ---")
            print(f"  Power:     {result['power_W']:.2f} W")
            print(f"  Current:   {result['current_A']:.2f} A")
            print(f"  Efficiency: {result['efficiency']:.3f}")
        
        print("\n" + "="*70)


def main():
    """Interactive prediction interface"""
    
    predictor = UniversalThrustPredictor()
    
    print("\n" + "="*70)
    print("UNIVERSAL THRUST PREDICTOR")
    print("="*70)
    
    while True:
        print("\nOptions:")
        print("  1. List available props")
        print("  2. Single prediction")
        print("  3. Throttle sweep")
        print("  4. Prop info")
        print("  5. Exit")
        
        choice = input("\nChoice: ").strip()
        
        if choice == '1':
            predictor.list_available_props()
        
        elif choice == '2':
            print("\nEnter configuration:")
            motor_kv = float(input("  Motor KV: "))
            voltage = float(input("  Voltage (V): "))
            prop_d = float(input("  Prop diameter (inches): "))
            prop_p = float(input("  Prop pitch (inches): "))
            throttle = float(input("  Throttle (%): "))
            
            result = predictor.predict(motor_kv, voltage, prop_d, prop_p, throttle)
            predictor.print_prediction(result)
        
        elif choice == '3':
            print("\nEnter configuration:")
            motor_kv = float(input("  Motor KV: "))
            voltage = float(input("  Voltage (V): "))
            prop_d = float(input("  Prop diameter (inches): "))
            prop_p = float(input("  Prop pitch (inches): "))
            
            df = predictor.predict_throttle_sweep(motor_kv, voltage, prop_d, prop_p)
            
            if not df.empty:
                print("\n" + "="*70)
                print("THROTTLE SWEEP RESULTS")
                print("="*70)
                print(df.to_string(index=False))
                
                # Save to CSV
                filename = f"prediction_{motor_kv}kv_{prop_d:.0f}x{prop_p:.0f}_{voltage:.1f}v_sweep.csv"
                df.to_csv(filename, index=False)
                print(f"\n✓ Saved to {filename}")
        
        elif choice == '4':
            prop_d = float(input("  Prop diameter (inches): "))
            prop_p = float(input("  Prop pitch (inches): "))
            
            info = predictor.get_calibration_info(prop_d, prop_p)
            if info:
                print(info)
            else:
                print(f"⚠ No calibration for {prop_d:.1f}x{prop_p:.1f}")
        
        elif choice == '5':
            print("\nGoodbye!")
            break
        
        else:
            print("Invalid choice!")


if __name__ == "__main__":
    main()
