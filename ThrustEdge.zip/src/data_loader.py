import pandas as pd
from pathlib import Path

RAW_DIR = Path("data/raw")

def load_all_excel():
    """Load all numbered Excel files from data/raw/"""
    files = sorted(RAW_DIR.glob("*.xlsx"))
    print(f"Found {len(files)} Excel files")
    
    dfs = []
    for i, f in enumerate(files, 1):
        try:
            df = pd.read_excel(f)
            df["source_file"] = f.name
            dfs.append(df)
            if i % 10 == 0:
                print(f"  Loaded {i} files...")
        except Exception as e:
            print(f"  Error loading {f.name}: {e}")
    
    if not dfs:
        raise RuntimeError("No Excel files loaded!")
    
    all_df = pd.concat(dfs, ignore_index=True)
    print(f"\n✓ Combined {len(all_df)} rows from {len(dfs)} files")
    return all_df

if __name__ == "__main__":
    print("=" * 60)
    print("LOADING EXCEL FILES")
    print("=" * 60)
    
    df = load_all_excel()
    print("\nDataset shape:", df.shape)
    print("\nColumns:", list(df.columns))
    print("\nFirst few rows:")
    print(df.head())
    
    # Save combined data
    output_path = "data/processed/raw_combined.csv"
    df.to_csv(output_path, index=False)
    print(f"\n✓ Saved to {output_path}")
