import joblib
import numpy as np

# Load calibration index
calibrations = joblib.load("models/calibrations/calibration_index.pkl")

def predict_thrust(motor_kv, voltage, prop_d, prop_p, throttle):
    """Universal thrust predictor using auto-calibrated props"""
    
    prop_key = f"{prop_d:.1f}x{prop_p:.1f}"
    
    if prop_key not in calibrations:
        print(f"⚠ No calibration for {prop_key}")
        print(f"Available props: {list(calibrations.keys())}")
        return None
    
    cal = calibrations[prop_key]
    ct_params = cal['ct_params']
    
    # Calculate RPM
    rpm = motor_kv * voltage * (throttle / 100)
    
    # Calculate C_T
    a, b, c = ct_params
    ct = a + b * np.log(rpm + 1) + c * rpm / 10000
    
    # Calculate thrust
    rho = 1.225
    D = prop_d * 0.0254
    n = rpm / 60
    thrust_N = ct * rho * (n ** 2) * (D ** 4)
    thrust_kgf = thrust_N / 9.81
    
    return {
        'rpm': rpm,
        'ct': ct,
        'thrust_kgf': thrust_kgf,
        'calibration_mape': cal['ct_mape']
    }

# Example usage
result = predict_thrust(1000, 11.1, 10.0, 4.5, 50)
print(result)
