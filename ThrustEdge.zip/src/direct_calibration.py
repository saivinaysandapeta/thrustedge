import pandas as pd
import numpy as np
import joblib
from scipy.optimize import curve_fit

class DirectCoefficientCalibrator:
    """
    Learn actual C_T and C_P curves from experimental data
    Then use as correction factors for predictions
    """
    
    def __init__(self):
        self.AIR_DENSITY = 1.225
        self.g = 9.81
    
    def inch_to_meter(self, inches):
        return inches * 0.0254
    
    def calculate_ct_from_data(self, thrust_kgf, rpm, diameter_inch):
        """Calculate actual C_T from experimental measurement"""
        thrust_N = thrust_kgf * self.g
        D = self.inch_to_meter(diameter_inch)
        n = rpm / 60
        
        if n < 1:
            return np.nan
        
        C_T = thrust_N / (self.AIR_DENSITY * (n ** 2) * (D ** 4))
        return C_T
    
    def fit_ct_curve(self, file_path='data/raw/216.xlsx'):
        """
        Fit C_T vs RPM curve from actual data
        """
        
        print("="*70)
        print("DIRECT CALIBRATION FROM THRUST STAND DATA")
        print("="*70)
        
        # Load actual data
        df = pd.read_excel(file_path)
        
        print(f"\nLoaded experimental data: 1700 Kv, 7x4 prop")
        print(f"Data points: {len(df)}")
        
        # Extract data
        throttle_col = [c for c in df.columns if 'throttle' in c.lower()][0]
        rpm_col = [c for c in df.columns if 'rotation' in c.lower() or 'rpm' in c.lower()][0]
        thrust_col = [c for c in df.columns if 'thrust' in c.lower()][0]
        
        rpm = df[rpm_col].values
        thrust = df[thrust_col].values
        
        # Calculate actual C_T
        prop_d = 7.0  # inches
        
        actual_ct = []
        valid_rpm = []
        
        for i in range(len(rpm)):
            if rpm[i] > 1000 and thrust[i] > 0:
                ct = self.calculate_ct_from_data(thrust[i], rpm[i], prop_d)
                if not np.isnan(ct) and ct > 0:
                    actual_ct.append(ct)
                    valid_rpm.append(rpm[i])
        
        actual_ct = np.array(actual_ct)
        valid_rpm = np.array(valid_rpm)
        
        print(f"\nValid data points: {len(actual_ct)}")
        print(f"\nActual C_T statistics:")
        print(f"  Mean: {np.mean(actual_ct):.6f}")
        print(f"  Std:  {np.std(actual_ct):.6f}")
        print(f"  Range: {np.min(actual_ct):.6f} to {np.max(actual_ct):.6f}")
        
        # Fit polynomial curve: C_T = f(RPM)
        def ct_model(rpm, a, b, c):
            """C_T increases with RPM (up to a point)"""
            return a + b * np.log(rpm + 1) + c * rpm / 10000
        
        params, _ = curve_fit(ct_model, valid_rpm, actual_ct)
        
        print(f"\nFitted C_T model parameters:")
        print(f"  a = {params[0]:.6f}")
        print(f"  b = {params[1]:.6f}")
        print(f"  c = {params[2]:.6f}")
        
        # Save calibration
        calibration = {
            'prop_size': '7x4',
            'ct_params': params,
            'rpm_range': (np.min(valid_rpm), np.max(valid_rpm)),
            'ct_mean': np.mean(actual_ct)
        }
        
        joblib.dump(calibration, 'models/ct_calibration_7x4.pkl')
        print(f"\n✓ Saved calibration to models/ct_calibration_7x4.pkl")
        
        # Show comparison
        print("\n" + "="*70)
        print("CALIBRATED vs MEASURED C_T")
        print("="*70)
        print(f"{'RPM':<10} {'Measured C_T':<15} {'Fitted C_T':<15} {'Error %':<10}")
        print("-"*70)
        
        for i in range(len(valid_rpm)):
            fitted = ct_model(valid_rpm[i], *params)
            error = abs(fitted - actual_ct[i]) / actual_ct[i] * 100
            print(f"{valid_rpm[i]:<10.0f} {actual_ct[i]:<15.6f} {fitted:<15.6f} {error:<10.2f}%")
        
        return calibration


if __name__ == "__main__":
    calibrator = DirectCoefficientCalibrator()
    calibrator.fit_ct_curve()
