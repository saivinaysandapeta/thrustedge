import joblib
import numpy as np
import pandas as pd

# Load ORIGINAL model
model_orig = joblib.load("models/propulsion_model.pkl")
scaler_orig = joblib.load("models/feature_scaler.pkl")
features_orig = joblib.load("models/feature_columns.pkl")
targets_orig = joblib.load("models/target_columns.pkl")

# Load ENHANCED model (after training)
try:
    model_enh = joblib.load("models/propulsion_model_enhanced.pkl")
    scaler_enh = joblib.load("models/feature_scaler_enhanced.pkl")
    features_enh = joblib.load("models/feature_columns_enhanced.pkl")
    targets_enh = joblib.load("models/target_columns_enhanced.pkl")
    enhanced_exists = True
except:
    print("Enhanced model not found. Train it first!")
    enhanced_exists = False
    exit()

print("="*70)
print("MODEL COMPARISON")
print("="*70)

print(f"\nOriginal Model:")
print(f"  Features: {len(features_orig)}")
print(f"  Targets:  {len(targets_orig)}")
print(f"  Features: {features_orig}")

print(f"\nEnhanced Model:")
print(f"  Features: {len(features_enh)}")
print(f"  Targets:  {len(targets_enh)}")
print(f"  Added:    +{len(features_enh) - len(features_orig)} physics features")

# Test prediction
print("\n" + "="*70)
print("TEST PREDICTION: 2850 Kv, 7x6 prop, 30A ESC, 11.1V, 1500µs")
print("="*70)

# Original model prediction
def predict_original(kv, prop_d, prop_p, esc, throttle, voltage):
    features = {
        "Motor_Kv": kv,
        "Prop_D_inch": prop_d,
        "Prop_P_inch": prop_p,
        "ESC_limit_A": esc,
        "Throttle_us": throttle,
        "Voltage_V": voltage,
    }
    x = np.array([[features[c] for c in features_orig]])
    x_scaled = scaler_orig.transform(x)
    return model_orig.predict(x_scaled)[0]

# Enhanced model prediction
def predict_enhanced(kv, prop_d, prop_p, esc, throttle, voltage):
    # Create enhanced features
    throttle_norm = (throttle - 1000) / 1000
    theoretical_rpm = kv * voltage * throttle_norm
    prop_load = prop_d ** 2 * prop_p
    disc_area = np.pi * (prop_d / 2) ** 2
    tip_speed = kv * voltage * prop_d * throttle_norm
    power_density = kv * voltage / esc
    aspect_ratio = prop_d / (prop_p + 0.1)
    v_times_esc = voltage * esc
    throttle_sq = throttle_norm ** 2
    
    # Kv category: 0=low, 1=med, 2=high
    if kv < 1500:
        kv_cat = 0
    elif kv < 3000:
        kv_cat = 1
    else:
        kv_cat = 2
    
    features = {
        "Motor_Kv": kv,
        "Prop_D_inch": prop_d,
        "Prop_P_inch": prop_p,
        "ESC_limit_A": esc,
        "Voltage_V": voltage,
        "Throttle_norm": throttle_norm,
        "Theoretical_RPM": theoretical_rpm,
        "Prop_load": prop_load,
        "Disc_area": disc_area,
        "Tip_speed_factor": tip_speed,
        "Power_density": power_density,
        "Aspect_ratio": aspect_ratio,
        "V_times_ESC": v_times_esc,
        "Throttle_squared": throttle_sq,
        "Kv_category": kv_cat,
    }
    
    x = np.array([[features[c] for c in features_enh]])
    x_scaled = scaler_enh.transform(x)
    return model_enh.predict(x_scaled)[0]

# Compare
pred_orig = predict_original(2850, 7.0, 6.0, 30, 1500, 11.1)
pred_enh = predict_enhanced(2850, 7.0, 6.0, 30, 1500, 11.1)

print(f"\n{'Target':<15} {'Original':<15} {'Enhanced':<15} {'Difference':<15}")
print("-"*65)
for i, target in enumerate(targets_orig):
    diff = pred_enh[i] - pred_orig[i]
    diff_pct = (diff / pred_orig[i] * 100) if pred_orig[i] != 0 else 0
    print(f"{target:<15} {pred_orig[i]:<15.2f} {pred_enh[i]:<15.2f} {diff:+.2f} ({diff_pct:+.1f}%)")

print("\n✓ Both models loaded and working!")
print("  Use whichever gives better results for your use case.")
