import pandas as pd
import numpy as np
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import r2_score, mean_absolute_error
import joblib

class RecalibratedAeroTrainer:
    """
    Recalibrate aerodynamic model with better low-RPM handling
    """
    
    def __init__(self):
        self.model_ct = None
        self.model_cp = None
        self.scaler_aero = None
    
    def prepare_features(self, df):
        """Enhanced features with low-RPM indicators"""
        
        features = pd.DataFrame({
            'Prop_D_inch': df['Prop_D_inch'],
            'Prop_P_inch': df['Prop_P_inch'],
            'Pitch_Ratio': df['Pitch_Ratio'],
            'RPM': df['RPM'],
            'RPM_squared': df['RPM'] ** 2,  # Thrust scales with RPM²
            'Tip_Speed_ms': df['Tip_Speed_ms'],
            'Tip_Speed_squared': df['Tip_Speed_ms'] ** 2,
            'Reynolds': np.log10(df['Reynolds'] + 1),
            'Low_RPM_flag': (df['RPM'] < 10000).astype(float),  # Flag for low RPM
        })
        
        return features
    
    def train(self, data_path="data/processed/physics_dataset.csv"):
        
        print("="*70)
        print("RECALIBRATING AERODYNAMIC MODEL")
        print("="*70)
        
        df = pd.read_csv(data_path)
        print(f"\nLoaded {len(df)} data points")
        
        # Weight samples: higher weight for mid-to-high RPM (more reliable)
        df['sample_weight'] = 1.0
        df.loc[df['RPM'] < 5000, 'sample_weight'] = 0.5  # Lower weight for very low RPM
        df.loc[df['RPM'] > 10000, 'sample_weight'] = 1.5  # Higher weight for high RPM
        
        X = self.prepare_features(df)
        y_ct = df['C_T'].values
        y_cp = df['C_P'].values
        weights = df['sample_weight'].values
        
        print(f"\nFeature columns: {list(X.columns)}")
        
        # Split
        X_train, X_test, y_ct_train, y_ct_test, y_cp_train, y_cp_test, w_train, w_test = train_test_split(
            X, y_ct, y_cp, weights, test_size=0.2, random_state=42
        )
        
        # Scale
        self.scaler_aero = StandardScaler()
        X_train_scaled = self.scaler_aero.fit_transform(X_train)
        X_test_scaled = self.scaler_aero.transform(X_test)
        
        # Train C_T with sample weights
        print("\n" + "-"*70)
        print("Training C_T model (weighted)...")
        print("-"*70)
        
        self.model_ct = GradientBoostingRegressor(
            n_estimators=300,
            max_depth=6,
            learning_rate=0.03,
            subsample=0.8,
            random_state=42
        )
        
        self.model_ct.fit(X_train_scaled, y_ct_train, sample_weight=w_train)
        
        y_ct_pred_test = self.model_ct.predict(X_test_scaled)
        
        print(f"C_T Model Performance:")
        print(f"  Test R²:  {r2_score(y_ct_test, y_ct_pred_test):.4f}")
        print(f"  Test MAE: {mean_absolute_error(y_ct_test, y_ct_pred_test):.6f}")
        
        # Train C_P
        print("\n" + "-"*70)
        print("Training C_P model (weighted)...")
        print("-"*70)
        
        self.model_cp = GradientBoostingRegressor(
            n_estimators=300,
            max_depth=6,
            learning_rate=0.03,
            subsample=0.8,
            random_state=42
        )
        
        self.model_cp.fit(X_train_scaled, y_cp_train, sample_weight=w_train)
        
        y_cp_pred_test = self.model_cp.predict(X_test_scaled)
        
        print(f"C_P Model Performance:")
        print(f"  Test R²:  {r2_score(y_cp_test, y_cp_pred_test):.4f}")
        print(f"  Test MAE: {mean_absolute_error(y_cp_test, y_cp_pred_test):.6f}")
        
        # Save
        joblib.dump(self.model_ct, 'models/aero_model_ct.pkl')
        joblib.dump(self.model_cp, 'models/aero_model_cp.pkl')
        joblib.dump(self.scaler_aero, 'models/aero_scaler.pkl')
        joblib.dump(list(X.columns), 'models/aero_features.pkl')
        
        print("\n✓ Saved recalibrated models")
        
        return self.model_ct, self.model_cp


if __name__ == "__main__":
    trainer = RecalibratedAeroTrainer()
    trainer.train()
