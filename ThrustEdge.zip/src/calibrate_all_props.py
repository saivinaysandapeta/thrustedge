import pandas as pd
import numpy as np
import joblib
import os
import glob
from scipy.optimize import curve_fit

class PropCalibrationSystem:
    """
    Automatically calibrate C_T and C_P curves for all available props
    from experimental thrust-stand data
    """
    
    def __init__(self):
        self.AIR_DENSITY = 1.225
        self.g = 9.81
        self.calibrations = {}
    
    def inch_to_meter(self, inches):
        return inches * 0.0254
    
    def calculate_ct_from_data(self, thrust_kgf, rpm, diameter_inch):
        """Calculate C_T from experimental measurement"""
        if rpm < 100 or thrust_kgf <= 0:
            return np.nan
        
        thrust_N = thrust_kgf * self.g
        D = self.inch_to_meter(diameter_inch)
        n = rpm / 60
        
        C_T = thrust_N / (self.AIR_DENSITY * (n ** 2) * (D ** 4) + 1e-10)
        return C_T
    
    def calculate_cp_from_data(self, mech_power_W, rpm, diameter_inch):
        """Calculate C_P from experimental measurement"""
        if rpm < 100 or mech_power_W <= 0:
            return np.nan
        
        D = self.inch_to_meter(diameter_inch)
        n = rpm / 60
        
        C_P = mech_power_W / (self.AIR_DENSITY * (n ** 3) * (D ** 5) + 1e-10)
        return C_P
    
    def detect_prop_size_from_data(self, df):
        """Auto-detect prop size from dataframe with robust parsing"""
        
        # Try to find diameter and pitch columns
        diameter_col = None
        pitch_col = None
        
        for col in df.columns:
            col_lower = str(col).lower()
            if 'diameter' in col_lower or 'size(diameter)' in col_lower:
                diameter_col = col
            if 'pitch' in col_lower or 'size(pitch)' in col_lower:
                pitch_col = col
        
        if diameter_col and pitch_col:
            diameter_raw = df[diameter_col].iloc[0]
            pitch_raw = df[pitch_col].iloc[0]
            
            # Parse diameter and pitch (handle string formats)
            try:
                # Remove spaces and convert to float
                if isinstance(diameter_raw, str):
                    diameter = float(diameter_raw.strip().replace('x', '').split()[0])
                else:
                    diameter = float(diameter_raw)
                
                if isinstance(pitch_raw, str):
                    pitch = float(pitch_raw.strip().replace('x', '').split()[0])
                else:
                    pitch = float(pitch_raw)
                
                return diameter, pitch
            except Exception as e:
                print(f"⚠ Error parsing prop size: {e}")
                print(f"  Raw values: diameter={diameter_raw}, pitch={pitch_raw}")
                return None, None
        
        return None, None
    
    def ct_model(self, rpm, a, b, c):
        """Parametric C_T model: C_T = a + b*log(rpm) + c*rpm/10000"""
        return a + b * np.log(rpm + 1) + c * rpm / 10000
    
    def cp_model(self, rpm, a, b, c):
        """Parametric C_P model: C_P = a + b*log(rpm) + c*rpm/10000"""
        return a + b * np.log(rpm + 1) + c * rpm / 10000
    
    def calibrate_single_prop(self, file_path, prop_d=None, prop_p=None):
        """Calibrate C_T and C_P for a single prop from data file"""
        
        print("\n" + "="*70)
        print(f"Processing: {os.path.basename(file_path)}")
        print("="*70)
        
        try:
            # Load data
            try:
                if file_path.endswith('.xlsx'):
                    df = pd.read_excel(file_path)
                elif file_path.endswith('.csv'):
                    df = pd.read_csv(file_path)
                else:
                    print(f"⚠ Unsupported file format: {file_path}")
                    return None
            except Exception as e:
                print(f"⚠ Error loading file: {e}")
                return None
            
            print(f"Loaded {len(df)} data points")
            
            # Auto-detect prop size if not provided
            if prop_d is None or prop_p is None:
                prop_d_detected, prop_p_detected = self.detect_prop_size_from_data(df)
                if prop_d_detected:
                    prop_d = prop_d_detected
                    prop_p = prop_p_detected
                    print(f"Auto-detected prop: {prop_d}x{prop_p} inches")
            
            if prop_d is None or prop_p is None:
                print("⚠ Could not determine prop size, skipping...")
                return None
            
            # Validate prop size is numeric
            try:
                prop_d = float(prop_d)
                prop_p = float(prop_p)
            except:
                print(f"⚠ Invalid prop size format: {prop_d}x{prop_p}")
                return None
            
            # Find required columns
            throttle_col = None
            rpm_col = None
            thrust_col = None
            mech_power_col = None
            
            for col in df.columns:
                col_lower = str(col).lower()
                if 'throttle' in col_lower:
                    throttle_col = col
                if 'rotation' in col_lower or 'rpm' in col_lower:
                    rpm_col = col
                if 'thrust' in col_lower and 'kgf' in col_lower:
                    thrust_col = col
                if 'mechanical power' in col_lower:
                    mech_power_col = col
            
            if not rpm_col or not thrust_col:
                print("⚠ Missing required columns (RPM or Thrust)")
                return None
            
            print(f"Using columns: RPM={rpm_col}, Thrust={thrust_col}")
            
            # Extract valid data
            rpm = df[rpm_col].values
            thrust = df[thrust_col].values
            
            if mech_power_col:
                mech_power = df[mech_power_col].values
            else:
                # Estimate mechanical power
                mech_power = None
            
            # Calculate C_T
            valid_ct = []
            valid_rpm_ct = []
            
            for i in range(len(rpm)):
                if rpm[i] > 1000 and thrust[i] > 0:
                    ct = self.calculate_ct_from_data(thrust[i], rpm[i], prop_d)
                    if not np.isnan(ct) and 0.001 < ct < 0.5:
                        valid_ct.append(ct)
                        valid_rpm_ct.append(rpm[i])
            
            if len(valid_ct) < 4:
                print(f"⚠ Insufficient valid C_T data points ({len(valid_ct)})")
                return None
            
            valid_ct = np.array(valid_ct)
            valid_rpm_ct = np.array(valid_rpm_ct)
            
            print(f"\nValid C_T data points: {len(valid_ct)}")
            print(f"C_T range: {np.min(valid_ct):.6f} to {np.max(valid_ct):.6f}")
            
            # Fit C_T curve
            try:
                ct_params, _ = curve_fit(self.ct_model, valid_rpm_ct, valid_ct, 
                                         p0=[0.03, 0.001, 0.005], maxfev=5000)
                
                # Validate fit
                ct_pred = self.ct_model(valid_rpm_ct, *ct_params)
                ct_mae = np.mean(np.abs(ct_pred - valid_ct))
                ct_mape = np.mean(np.abs(ct_pred - valid_ct) / valid_ct * 100)
                
                print(f"C_T model fitted:")
                print(f"  Parameters: a={ct_params[0]:.6f}, b={ct_params[1]:.6f}, c={ct_params[2]:.6f}")
                print(f"  MAE: {ct_mae:.6f}")
                print(f"  MAPE: {ct_mape:.2f}%")
                
            except Exception as e:
                print(f"⚠ C_T curve fitting failed: {e}")
                ct_params = None
                ct_mape = 999
            
            # Calculate C_P (if mechanical power available)
            cp_params = None
            cp_mape = 999
            
            if mech_power is not None:
                valid_cp = []
                valid_rpm_cp = []
                
                for i in range(len(rpm)):
                    if rpm[i] > 1000 and mech_power[i] > 0:
                        cp = self.calculate_cp_from_data(mech_power[i], rpm[i], prop_d)
                        if not np.isnan(cp) and 0.001 < cp < 0.5:
                            valid_cp.append(cp)
                            valid_rpm_cp.append(rpm[i])
                
                if len(valid_cp) >= 4:
                    valid_cp = np.array(valid_cp)
                    valid_rpm_cp = np.array(valid_rpm_cp)
                    
                    print(f"\nValid C_P data points: {len(valid_cp)}")
                    print(f"C_P range: {np.min(valid_cp):.6f} to {np.max(valid_cp):.6f}")
                    
                    try:
                        cp_params, _ = curve_fit(self.cp_model, valid_rpm_cp, valid_cp,
                                                p0=[0.02, 0.001, 0.003], maxfev=5000)
                        
                        cp_pred = self.cp_model(valid_rpm_cp, *cp_params)
                        cp_mae = np.mean(np.abs(cp_pred - valid_cp))
                        cp_mape = np.mean(np.abs(cp_pred - valid_cp) / valid_cp * 100)
                        
                        print(f"C_P model fitted:")
                        print(f"  Parameters: a={cp_params[0]:.6f}, b={cp_params[1]:.6f}, c={cp_params[2]:.6f}")
                        print(f"  MAE: {cp_mae:.6f}")
                        print(f"  MAPE: {cp_mape:.2f}%")
                        
                    except Exception as e:
                        print(f"⚠ C_P curve fitting failed: {e}")
            
            # Save calibration
            if ct_params is not None:
                prop_key = f"{prop_d:.1f}x{prop_p:.1f}"
                
                calibration = {
                    'prop_diameter': float(prop_d),
                    'prop_pitch': float(prop_p),
                    'ct_params': ct_params.tolist(),
                    'cp_params': cp_params.tolist() if cp_params is not None else None,
                    'rpm_range': (float(np.min(valid_rpm_ct)), float(np.max(valid_rpm_ct))),
                    'ct_range': (float(np.min(valid_ct)), float(np.max(valid_ct))),
                    'ct_mape': float(ct_mape),
                    'cp_mape': float(cp_mape) if cp_params is not None else None,
                    'data_points': len(valid_ct),
                    'source_file': os.path.basename(file_path)
                }
                
                self.calibrations[prop_key] = calibration
                print(f"\n✓ Calibration saved for {prop_key}")
                
                return calibration
            
        except Exception as e:
            print(f"⚠ Unexpected error: {e}")
            return None
        
        return None
    
    def calibrate_all_from_directory(self, data_dir="data/raw"):
        """Scan directory and calibrate all available props"""
        
        print("="*70)
        print("AUTOMATIC PROP CALIBRATION SYSTEM")
        print("="*70)
        print(f"\nScanning directory: {data_dir}")
        
        # Find all Excel and CSV files
        excel_files = glob.glob(f"{data_dir}/*.xlsx")
        csv_files = glob.glob(f"{data_dir}/*.csv")
        
        all_files = excel_files + csv_files
        
        print(f"Found {len(all_files)} data files")
        
        success_count = 0
        error_count = 0
        
        for idx, file_path in enumerate(all_files, 1):
            print(f"\n[{idx}/{len(all_files)}]", end=" ")
            result = self.calibrate_single_prop(file_path)
            if result:
                success_count += 1
            else:
                error_count += 1
        
        print("\n" + "="*70)
        print("CALIBRATION SUMMARY")
        print("="*70)
        print(f"\nProcessed: {len(all_files)} files")
        print(f"Success: {success_count}")
        print(f"Errors/Skipped: {error_count}")
        print(f"\nSuccessfully calibrated {len(self.calibrations)} unique prop sizes:")
        
        for prop_key, cal in sorted(self.calibrations.items()):
            print(f"\n  {prop_key}:")
            print(f"    Data points: {cal['data_points']}")
            print(f"    RPM range: {cal['rpm_range'][0]:.0f} - {cal['rpm_range'][1]:.0f}")
            print(f"    C_T MAPE: {cal['ct_mape']:.2f}%")
            if cal['cp_mape']:
                print(f"    C_P MAPE: {cal['cp_mape']:.2f}%")
            print(f"    Source: {cal['source_file']}")
        
        # Save all calibrations
        os.makedirs("models/calibrations", exist_ok=True)
        
        for prop_key, cal in self.calibrations.items():
            safe_key = prop_key.replace('.', '_').replace('x', '_')
            filename = f"models/calibrations/cal_{safe_key}.pkl"
            joblib.dump(cal, filename)
        
        print(f"\n✓ Saved {len(self.calibrations)} calibration files to models/calibrations/")
        
        # Save master index
        joblib.dump(self.calibrations, "models/calibrations/calibration_index.pkl")
        print(f"✓ Saved master index: models/calibrations/calibration_index.pkl")
        
        print("\n" + "="*70)
        print("✓ CALIBRATION COMPLETE!")
        print("="*70)
        
        return self.calibrations


if __name__ == "__main__":
    system = PropCalibrationSystem()
    calibrations = system.calibrate_all_from_directory("data/raw")
