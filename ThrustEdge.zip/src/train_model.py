import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.multioutput import MultiOutputRegressor
from sklearn.metrics import r2_score, mean_absolute_error
import xgboost as xgb
import joblib
import os

DATA_CSV = "data/processed/train_dataset.csv"
MODEL_DIR = "models"

def main():
    print("=" * 60)
    print("TRAINING MODEL")
    print("=" * 60)
    
    df = pd.read_csv(DATA_CSV)
    print(f"\nLoaded {len(df)} training samples")
    
    feature_cols = ["Motor_Kv", "Prop_D_inch", "Prop_P_inch",
                    "ESC_limit_A", "Throttle_us", "Voltage_V"]
    
    # Check which target columns have enough data
    candidate_targets = [
        "RPM",
        "Thrust_kgf",
        "ElecPower_W",
        "Prop_eff_gf_per_W",
    ]
    
    print("\nChecking target columns for NaN values:")
    target_cols = []
    for col in candidate_targets:
        if col in df.columns:
            nan_count = df[col].isna().sum()
            nan_pct = (nan_count / len(df)) * 100
            print(f"  {col}: {nan_count} NaN ({nan_pct:.1f}%)")
            
            # Only use columns with less than 50% NaN
            if nan_pct < 50:
                target_cols.append(col)
                print(f"    ✓ Will use for training")
            else:
                print(f"    ✗ Too many NaN - skipping")
    
    if not target_cols:
        print("\nERROR: No valid target columns!")
        return
    
    print(f"\nFinal targets: {target_cols}")
    
    # Drop any rows with NaN in selected targets or features
    all_needed = feature_cols + target_cols
    before = len(df)
    df = df.dropna(subset=all_needed)
    print(f"\nDropped {before - len(df)} rows with NaN in features/targets")
    print(f"Final dataset: {len(df)} rows")
    
    if len(df) < 100:
        print("\nERROR: Not enough data after cleaning!")
        return
    
    print(f"\nFeatures: {feature_cols}")
    print(f"Targets: {target_cols}")
    
    X = df[feature_cols].values
    y = df[target_cols].values
    
    # Split data
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )
    print(f"\nTrain samples: {len(X_train)}")
    print(f"Test samples: {len(X_test)}")
    
    # Scale features
    print("\nScaling features...")
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    # Train model
    print("\nTraining XGBoost model...")
    base_model = xgb.XGBRegressor(
        n_estimators=200,
        max_depth=6,
        learning_rate=0.05,
        subsample=0.8,
        colsample_bytree=0.8,
        random_state=42,
        n_jobs=-1,
    )
    
    if len(target_cols) > 1:
        model = MultiOutputRegressor(base_model)
    else:
        model = base_model
    
    model.fit(X_train_scaled, y_train)
    
    # Evaluate
    print("\nEvaluating model...")
    y_pred = model.predict(X_test_scaled)
    
    if len(target_cols) > 1:
        r2_scores = r2_score(y_test, y_pred, multioutput='raw_values')
        mae_scores = mean_absolute_error(y_test, y_pred, multioutput='raw_values')
    else:
        r2_scores = [r2_score(y_test, y_pred)]
        mae_scores = [mean_absolute_error(y_test, y_pred)]
    
    print("\n" + "=" * 60)
    print("MODEL PERFORMANCE")
    print("=" * 60)
    for i, col in enumerate(target_cols):
        print(f"\n{col}:")
        print(f"  R² Score: {r2_scores[i]:.4f}")
        print(f"  MAE: {mae_scores[i]:.4f}")
    
    avg_r2 = np.mean(r2_scores)
    print(f"\nAverage R² Score: {avg_r2:.4f}")
    
    # Save model
    os.makedirs(MODEL_DIR, exist_ok=True)
    joblib.dump(model, f"{MODEL_DIR}/propulsion_model.pkl")
    joblib.dump(scaler, f"{MODEL_DIR}/feature_scaler.pkl")
    joblib.dump(feature_cols, f"{MODEL_DIR}/feature_columns.pkl")
    joblib.dump(target_cols, f"{MODEL_DIR}/target_columns.pkl")
    
    print(f"\n{'='*60}")
    print("✓ MODEL SAVED!")
    print(f"{'='*60}")
    print(f"Location: {MODEL_DIR}/")
    print(f"Files: propulsion_model.pkl, feature_scaler.pkl, *.pkl")

if __name__ == "__main__":
    main()
