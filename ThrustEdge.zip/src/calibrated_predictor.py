import joblib
import numpy as np
import pandas as pd
import os

class CalibratedPredictor:
    """
    Physics-informed predictor with prop-specific calibration
    Uses learned C_T curves from actual thrust-stand data
    """
    
    def __init__(self, models_dir="models"):
        self.AIR_DENSITY = 1.225
        self.g = 9.81
        
        print("Loading models and calibrations...")
        
        # Load motor model
        self.model_rpm = joblib.load(f"{models_dir}/motor_model_rpm.pkl")
        self.model_current = joblib.load(f"{models_dir}/motor_model_current.pkl")
        self.scaler_motor = joblib.load(f"{models_dir}/motor_scaler.pkl")
        
        # Load calibration (if available)
        try:
            self.calibration = joblib.load(f"{models_dir}/ct_calibration_7x4.pkl")
            print("✓ Loaded C_T calibration for 7x4 prop")
        except:
            self.calibration = None
            print("⚠ No calibration found, using ML model")
        
        print("✓ All models loaded")
    
    def inch_to_meter(self, inches):
        return inches * 0.0254
    
    def ct_model_calibrated(self, rpm, params):
        """Calibrated C_T model"""
        a, b, c = params
        return a + b * np.log(rpm + 1) + c * rpm / 10000
    
    def predict_thrust_calibrated(self, rpm, diameter_inch, pitch_inch):
        """
        Predict thrust using calibrated C_T curve
        """
        if rpm < 100:
            return 0.0
        
        # Use calibration if available and prop matches
        if self.calibration and diameter_inch == 7.0 and pitch_inch == 4.0:
            C_T = self.ct_model_calibrated(rpm, self.calibration['ct_params'])
        else:
            # Fallback: use physics approximation
            C_T = 0.028  # Average from calibration
        
        # Clip to reasonable bounds
        C_T = np.clip(C_T, 0.01, 0.15)
        
        # Calculate thrust
        D = self.inch_to_meter(diameter_inch)
        n = rpm / 60
        
        thrust_N = C_T * self.AIR_DENSITY * (n ** 2) * (D ** 4)
        thrust_kgf = thrust_N / self.g
        
        return thrust_kgf
    
    def estimate_mechanical_power(self, rpm, thrust_kgf, diameter_inch, pitch_inch):
        """Estimate mechanical power from thrust"""
        if rpm < 100:
            return 0.0
        
        thrust_N = thrust_kgf * self.g
        D = self.inch_to_meter(diameter_inch)
        A = np.pi * (D/2) ** 2
        
        v_induced = np.sqrt(thrust_N / (2 * self.AIR_DENSITY * A + 1e-10))
        
        pitch_ratio = pitch_inch / diameter_inch
        correction = 1.0 + 0.5 * pitch_ratio
        
        mech_power = thrust_N * v_induced * correction
        
        return mech_power
    
    def predict_single_point(self, motor_kv, prop_d, prop_p, esc_limit, throttle_us, voltage):
        """Predict single operating point"""
        
        throttle_pct = (throttle_us - 1000) / 1000
        
        if throttle_us < 1100:
            return {
                'Throttle_us': throttle_us,
                'RPM': 0,
                'Thrust_kgf': 0,
                'Current_A': 0,
                'Voltage_V': voltage,
                'ElecPower_W': 0,
                'MechPower_W': 0,
                'Efficiency_gf_per_W': 0
            }
        
        # Predict RPM and Current
        motor_features = pd.DataFrame({
            'Motor_Kv': [motor_kv],
            'Voltage_V': [voltage],
            'ESC_limit_A': [esc_limit],
            'Throttle_pct': [throttle_pct],
            'Prop_D_inch': [prop_d],
            'Prop_P_inch': [prop_p],
            'Prop_load': [prop_d ** 2 * prop_p]
        })
        
        motor_features_scaled = self.scaler_motor.transform(motor_features)
        
        rpm = self.model_rpm.predict(motor_features_scaled)[0]
        current = self.model_current.predict(motor_features_scaled)[0]
        
        rpm = max(0, rpm)
        current = max(0, current)
        
        # Predict thrust using CALIBRATED model
        thrust = self.predict_thrust_calibrated(rpm, prop_d, prop_p)
        
        # Calculate mechanical power
        mech_power = self.estimate_mechanical_power(rpm, thrust, prop_d, prop_p)
        
        # Electrical power
        elec_power = voltage * current
        
        # Efficiency
        efficiency = (thrust * 1000) / (elec_power + 0.1)
        
        return {
            'Throttle_us': int(throttle_us),
            'RPM': round(rpm, 1),
            'Thrust_kgf': round(thrust, 6),
            'Current_A': round(current, 3),
            'Voltage_V': round(voltage, 2),
            'ElecPower_W': round(elec_power, 2),
            'MechPower_W': round(mech_power, 2),
            'Efficiency_gf_per_W': round(efficiency, 3)
        }
    
    def generate_csv(self, motor_kv, prop_d, prop_p, esc_limit, voltage,
                     throttle_start=1000, throttle_end=2000, throttle_step=50,
                     output_dir="predictions"):
        """Generate calibrated performance CSV"""
        
        print("="*70)
        print("CALIBRATED PHYSICS-INFORMED PREDICTION")
        print("="*70)
        
        print(f"\nConfiguration:")
        print(f"  Motor Kv:       {motor_kv}")
        print(f"  Propeller:      {prop_d}x{prop_p} inches")
        print(f"  ESC:            {esc_limit}A")
        print(f"  Voltage:        {voltage}V")
        
        if self.calibration and prop_d == 7.0 and prop_p == 4.0:
            print(f"  ✓ Using calibrated C_T model for 7x4 prop")
        else:
            print(f"  ⚠ No calibration for this prop, using physics approximation")
        
        throttle_points = range(throttle_start, throttle_end + 1, throttle_step)
        results = []
        
        for throttle in throttle_points:
            result = self.predict_single_point(
                motor_kv, prop_d, prop_p, esc_limit, throttle, voltage
            )
            results.append(result)
        
        df = pd.DataFrame(results)
        
        df.insert(0, 'Motor_Kv', motor_kv)
        df.insert(1, 'Prop_D_inch', prop_d)
        df.insert(2, 'Prop_P_inch', prop_p)
        df.insert(3, 'ESC_limit_A', esc_limit)
        
        print("\n" + "="*70)
        print("SAMPLE PREDICTIONS")
        print("="*70)
        print(df[['Throttle_us', 'RPM', 'Thrust_kgf', 'Current_A', 
                  'ElecPower_W', 'Efficiency_gf_per_W']].head(12))
        
        print("\n" + "="*70)
        print("PERFORMANCE SUMMARY")
        print("="*70)
        print(f"  Max RPM:         {df['RPM'].max():.0f}")
        print(f"  Max Thrust:      {df['Thrust_kgf'].max():.3f} kgf ({df['Thrust_kgf'].max()*1000:.1f} gf)")
        print(f"  Max Current:     {df['Current_A'].max():.2f} A")
        print(f"  Max Power:       {df['ElecPower_W'].max():.1f} W")
        print(f"  Best Efficiency: {df['Efficiency_gf_per_W'].max():.2f} gf/W")
        
        os.makedirs(output_dir, exist_ok=True)
        filename = f"{output_dir}/calibrated_pred_{int(motor_kv)}kv_{prop_d}x{prop_p}_{voltage}v.csv"
        df.to_csv(filename, index=False)
        
        print(f"\n✓ Saved to: {filename}")
        print("="*70)
        
        return df


if __name__ == "__main__":
    predictor = CalibratedPredictor()
    
    # Generate prediction for 1700 Kv, 7x4 (with calibration)
    df = predictor.generate_csv(
        motor_kv=1700,
        prop_d=7.0,
        prop_p=4.0,
        esc_limit=50,
        voltage=12.6
    )
