import pandas as pd
import numpy as np
import os

class PhysicsDatasetBuilder:
    """
    Build unified physics-aware dataset from experimental CSVs
    
    KEY FIX: Use mechanical power, not electrical power for C_P
    """
    
    def __init__(self):
        self.AIR_DENSITY = 1.225  # kg/m³
        self.g = 9.81  # m/s²
        self.kinematic_viscosity = 1.5e-5  # m²/s for air at 20°C
    
    def inch_to_meter(self, inches):
        return inches * 0.0254
    
    def calculate_reynolds(self, tip_speed_ms, diameter_inch):
        """Calculate Reynolds number at prop tip"""
        D = self.inch_to_meter(diameter_inch)
        Re = tip_speed_ms * D / self.kinematic_viscosity
        return Re
    
    def estimate_mechanical_power(self, rpm, thrust_kgf, diameter_inch, pitch_inch):
        """
        Estimate mechanical power from thrust and RPM
        Using approximate propeller theory
        """
        if rpm < 100:
            return 0.0
        
        # Convert thrust to N
        thrust_N = thrust_kgf * self.g
        
        # Estimate induced velocity using momentum theory
        D = self.inch_to_meter(diameter_inch)
        A = np.pi * (D/2) ** 2  # Disc area
        
        # v_induced ≈ sqrt(T / (2 × ρ × A))
        v_induced = np.sqrt(thrust_N / (2 * self.AIR_DENSITY * A + 1e-10))
        
        # Mechanical power ≈ T × v_induced (ideal)
        # Add empirical correction for non-ideal losses
        mech_power_ideal = thrust_N * v_induced
        
        # Correction factor based on pitch (higher pitch = more power)
        pitch_ratio = pitch_inch / diameter_inch
        correction = 1.0 + 0.5 * pitch_ratio
        
        mech_power = mech_power_ideal * correction
        
        return mech_power
    
    def calculate_ct(self, thrust_kgf, rpm, diameter_inch):
        """C_T = T / (ρ × n² × D⁴)"""
        if rpm < 100:
            return np.nan
        
        thrust_N = thrust_kgf * self.g
        D = self.inch_to_meter(diameter_inch)
        n = rpm / 60
        
        denominator = self.AIR_DENSITY * (n ** 2) * (D ** 4)
        
        if denominator < 1e-10:
            return np.nan
        
        C_T = thrust_N / denominator
        return C_T
    
    def calculate_cp(self, mech_power_W, rpm, diameter_inch):
        """C_P = P_mech / (ρ × n³ × D⁵)"""
        if rpm < 100 or mech_power_W <= 0:
            return np.nan
        
        D = self.inch_to_meter(diameter_inch)
        n = rpm / 60
        
        denominator = self.AIR_DENSITY * (n ** 3) * (D ** 5)
        
        if denominator < 1e-10:
            return np.nan
        
        C_P = mech_power_W / denominator
        return C_P
    
    def build_unified_dataset(self, data_dir="data/processed"):
        """
        Load train_dataset.csv and compute physics features
        """
        
        print("="*70)
        print("BUILDING PHYSICS-INFORMED DATASET (CORRECTED)")
        print("="*70)
        
        df = pd.read_csv(f"{data_dir}/train_dataset.csv")
        print(f"\nLoaded {len(df)} raw data points")
        
        # Compute non-dimensional parameters FIRST
        print("\nComputing non-dimensional parameters...")
        
        df['Pitch_Ratio'] = df['Prop_P_inch'] / df['Prop_D_inch']
        
        df['Tip_Speed_ms'] = df.apply(
            lambda row: (row['RPM'] / 60) * np.pi * self.inch_to_meter(row['Prop_D_inch']),
            axis=1
        )
        
        # Reynolds number
        df['Reynolds'] = df.apply(
            lambda row: self.calculate_reynolds(row['Tip_Speed_ms'], row['Prop_D_inch']),
            axis=1
        )
        
        # Throttle percentage
        df['Throttle_pct'] = (df['Throttle_us'] - 1000) / 1000
        
        # Estimate mechanical power (this is the KEY fix)
        print("Estimating mechanical power from thrust & RPM...")
        df['MechPower_W'] = df.apply(
            lambda row: self.estimate_mechanical_power(
                row['RPM'], row['Thrust_kgf'], 
                row['Prop_D_inch'], row['Prop_P_inch']
            ),
            axis=1
        )
        
        # Compute aerodynamic coefficients
        print("Computing aerodynamic coefficients (C_T, C_P)...")
        
        df['C_T'] = df.apply(
            lambda row: self.calculate_ct(
                row['Thrust_kgf'], row['RPM'], row['Prop_D_inch']
            ),
            axis=1
        )
        
        df['C_P'] = df.apply(
            lambda row: self.calculate_cp(
                row['MechPower_W'], row['RPM'], row['Prop_D_inch']
            ),
            axis=1
        )
        
        # Motor efficiency (electrical → mechanical)
        df['Motor_Efficiency'] = df['MechPower_W'] / (df['ElecPower_W'] + 0.1)
        df['Motor_Efficiency'] = df['Motor_Efficiency'].clip(0, 1)  # Cap at 100%
        
        # Propeller efficiency (thrust power / mechanical power)
        df['Prop_Efficiency'] = (df['Thrust_kgf'] * self.g * df.apply(
            lambda row: np.sqrt(row['Thrust_kgf'] * self.g / 
                               (2 * self.AIR_DENSITY * np.pi * (self.inch_to_meter(row['Prop_D_inch'])/2)**2 + 1e-10)),
            axis=1
        )) / (df['MechPower_W'] + 0.1)
        df['Prop_Efficiency'] = df['Prop_Efficiency'].clip(0, 1)
        
        # Clean invalid data with STRICT bounds
        df_clean = df.dropna(subset=['C_T', 'C_P', 'Reynolds'])
        
        # Physically reasonable C_T range (from literature)
        df_clean = df_clean[(df_clean['C_T'] > 0.001) & (df_clean['C_T'] < 0.5)]
        
        # Physically reasonable C_P range
        df_clean = df_clean[(df_clean['C_P'] > 0.001) & (df_clean['C_P'] < 0.5)]
        
        df_clean = df_clean[df_clean['RPM'] > 100]
        df_clean = df_clean[df_clean['Thrust_kgf'] > 0]
        df_clean = df_clean[df_clean['Reynolds'] > 1000]  # Minimum Reynolds
        
        print(f"\n✓ Valid data points after filtering: {len(df_clean)}")
        
        # Statistics
        print("\n" + "="*70)
        print("AERODYNAMIC COEFFICIENT STATISTICS")
        print("="*70)
        print(f"\nC_T (Thrust Coefficient):")
        print(f"  Mean:   {df_clean['C_T'].mean():.6f}")
        print(f"  Std:    {df_clean['C_T'].std():.6f}")
        print(f"  Range:  {df_clean['C_T'].min():.6f} to {df_clean['C_T'].max():.6f}")
        print(f"  ✓ Target: 0.01 to 0.15 (typical)")
        
        print(f"\nC_P (Power Coefficient):")
        print(f"  Mean:   {df_clean['C_P'].mean():.6f}")
        print(f"  Std:    {df_clean['C_P'].std():.6f}")
        print(f"  Range:  {df_clean['C_P'].min():.6f} to {df_clean['C_P'].max():.6f}")
        print(f"  ✓ Target: 0.01 to 0.08 (typical)")
        
        print(f"\nMotor Efficiency:")
        print(f"  Mean:   {df_clean['Motor_Efficiency'].mean():.3f}")
        print(f"  Range:  {df_clean['Motor_Efficiency'].min():.3f} to {df_clean['Motor_Efficiency'].max():.3f}")
        
        print(f"\nReynolds Number:")
        print(f"  Mean:   {df_clean['Reynolds'].mean():.0f}")
        print(f"  Range:  {df_clean['Reynolds'].min():.0f} to {df_clean['Reynolds'].max():.0f}")
        
        # Save
        output_path = f"{data_dir}/physics_dataset.csv"
        df_clean.to_csv(output_path, index=False)
        print(f"\n✓ Saved physics dataset to: {output_path}")
        
        return df_clean


if __name__ == "__main__":
    builder = PhysicsDatasetBuilder()
    df = builder.build_unified_dataset()
    
    print("\n" + "="*70)
    print("SAMPLE PHYSICS DATA")
    print("="*70)
    print(df[['Motor_Kv', 'Prop_D_inch', 'Prop_P_inch', 'RPM', 'Thrust_kgf',
              'MechPower_W', 'ElecPower_W', 'C_T', 'C_P', 'Reynolds', 'Motor_Efficiency']].head(15))
