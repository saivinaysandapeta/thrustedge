import pandas as pd

df = pd.read_csv("data/processed/train_dataset.csv")

print("="*70)
print("CHECKING LOW THROTTLE DATA")
print("="*70)

# Check for 1000 Kv motor
print("\n1. Checking 1000 Kv motor data:")
kv_1000 = df[df['Motor_Kv'] == 1000]
print(f"   Found {len(kv_1000)} samples")

if len(kv_1000) > 0:
    print("\n   Sample data:")
    print(kv_1000[['Motor_Kv', 'Prop_D_inch', 'Throttle_us', 'RPM', 'Thrust_kgf', 'ElecPower_W']].head(20))

# Check low throttle across all motors
print("\n2. Checking throttle 1000-1200 µs across ALL motors:")
low_throttle = df[df['Throttle_us'] <= 1200]
print(f"   Found {len(low_throttle)} samples")

if len(low_throttle) > 0:
    print("\n   RPM statistics at low throttle:")
    print(f"   Min RPM: {low_throttle['RPM'].min()}")
    print(f"   Max RPM: {low_throttle['RPM'].max()}")
    print(f"   Negative RPM count: {(low_throttle['RPM'] < 0).sum()}")
    
    print("\n   Power statistics at low throttle:")
    print(f"   Min Power: {low_throttle['ElecPower_W'].min()}")
    print(f"   Max Power: {low_throttle['ElecPower_W'].max()}")
    print(f"   Negative Power count: {(low_throttle['ElecPower_W'] < 0).sum()}")

# Check if 10-inch prop exists in data
print("\n3. Checking 10-inch propeller data:")
prop_10 = df[df['Prop_D_inch'] == 10.0]
print(f"   Found {len(prop_10)} samples with 10\" props")

if len(prop_10) > 0:
    print(f"   Kv range: {prop_10['Motor_Kv'].min()} - {prop_10['Motor_Kv'].max()}")
    print(f"   Throttle range: {prop_10['Throttle_us'].min()} - {prop_10['Throttle_us'].max()}")

# Check the specific combo
print("\n4. Checking 1000 Kv + 10\" prop combination:")
combo = df[(df['Motor_Kv'] == 1000) & (df['Prop_D_inch'] == 10.0)]
print(f"   Found {len(combo)} samples")

if len(combo) == 0:
    print("\n   ⚠️  This combination does NOT exist in training data!")
    print("   Model is EXTRAPOLATING - predictions unreliable!")
    
    # Find closest match
    print("\n   Finding closest motor Kv with 10\" prop:")
    if len(prop_10) > 0:
        closest_kv = prop_10.iloc[(prop_10['Motor_Kv'] - 1000).abs().argsort()[:5]]
        print(closest_kv[['Motor_Kv', 'Prop_D_inch', 'Prop_P_inch', 'Throttle_us', 'RPM', 'ElecPower_W']].to_string())

print("\n" + "="*70)
