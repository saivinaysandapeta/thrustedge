import joblib
import numpy as np
import pandas as pd
import os

MODEL_DIR = "models"
OUTPUT_DIR = "predictions"

def create_enhanced_features(motor_kv, prop_d, prop_p, esc_limit, throttle_us, voltage_v):
    """
    Create features in EXACT order matching training:
    1. Motor_Kv, 2. Prop_D_inch, 3. Prop_P_inch, 4. ESC_limit_A, 5. Voltage_V,
    6. Throttle_norm, 7. Theoretical_RPM, 8. Prop_load, 9. Disc_area,
    10. Tip_speed_factor, 11. Power_density, 12. Aspect_ratio,
    13. V_times_ESC, 14. Throttle_squared, 15. Kv_category
    """
    
    throttle_norm = (throttle_us - 1000) / 1000
    theoretical_rpm = motor_kv * voltage_v * throttle_norm
    prop_load = prop_d ** 2 * prop_p
    disc_area = np.pi * (prop_d / 2) ** 2
    tip_speed_factor = motor_kv * voltage_v * prop_d * throttle_norm
    power_density = motor_kv * voltage_v / (esc_limit + 0.1)
    aspect_ratio = prop_d / (prop_p + 0.1)
    v_times_esc = voltage_v * esc_limit
    throttle_squared = throttle_norm ** 2
    
    if motor_kv < 1500:
        kv_category = 0.0
    elif motor_kv < 3000:
        kv_category = 1.0
    else:
        kv_category = 2.0
    
    return [
        motor_kv, prop_d, prop_p, esc_limit, voltage_v,
        throttle_norm, theoretical_rpm, prop_load, disc_area,
        tip_speed_factor, power_density, aspect_ratio,
        v_times_esc, throttle_squared, kv_category
    ]

def generate_prediction_curve(motor_kv, prop_d, prop_p, esc_limit, voltage_v, 
                             throttle_start=1000, throttle_end=2000, throttle_step=50):
    """Generate performance curve using Enhanced model"""
    
    print("=" * 70)
    print("ENHANCED MODEL PREDICTION")
    print("=" * 70)
    
    # Load enhanced model
    try:
        model = joblib.load(f"{MODEL_DIR}/propulsion_model_enhanced.pkl")
        scaler = joblib.load(f"{MODEL_DIR}/feature_scaler_enhanced.pkl")
        feature_names = joblib.load(f"{MODEL_DIR}/feature_columns_enhanced.pkl")
        target_names = joblib.load(f"{MODEL_DIR}/target_columns_enhanced.pkl")
        print("\n✓ Enhanced model loaded successfully!")
    except FileNotFoundError as e:
        print(f"\n❌ Enhanced model not found: {e}")
        return None
    
    print(f"\nConfiguration:")
    print(f"  Motor Kv:       {motor_kv}")
    print(f"  Propeller:      {prop_d}x{prop_p} inches")
    print(f"  ESC:            {esc_limit}A")
    print(f"  Voltage:        {voltage_v}V")
    print(f"  Throttle range: {throttle_start}-{throttle_end} µs (step {throttle_step})")
    
    # Generate throttle points
    throttle_points = range(throttle_start, throttle_end + 1, throttle_step)
    
    # Prepare data
    X_list = []
    for throttle in throttle_points:
        features_row = create_enhanced_features(
            motor_kv, prop_d, prop_p, esc_limit, throttle, voltage_v
        )
        X_list.append(features_row)
    
    X = np.array(X_list)
    X_scaled = scaler.transform(X)
    predictions = model.predict(X_scaled)
    
    # Create results dataframe
    results = pd.DataFrame({
        'Motor_Kv': motor_kv,
        'Prop_D_inch': prop_d,
        'Prop_P_inch': prop_p,
        'ESC_limit_A': esc_limit,
        'Voltage_V': voltage_v,
        'Throttle_us': list(throttle_points),
        'RPM': predictions[:, 0],
        'Thrust_kgf': predictions[:, 1],
        'ElecPower_W': predictions[:, 2],
    })
    
    results['Efficiency_g_per_W'] = (results['Thrust_kgf'] * 1000) / (results['ElecPower_W'] + 0.1)
    
    print("\n" + "=" * 70)
    print("PREDICTION RESULTS (Sample)")
    print("=" * 70)
    print(results.head(10).to_string(index=False))
    
    # Save
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    filename = f"{OUTPUT_DIR}/prediction_{int(motor_kv)}kv_{prop_d}x{prop_p}_{voltage_v}v_enhanced.csv"
    results.to_csv(filename, index=False)
    
    print("\n" + "=" * 70)
    print(f"✓ SAVED: {filename}")
    print("=" * 70)
    
    # Summary
    print("\nPerformance Summary:")
    print(f"  Max RPM:         {results['RPM'].max():.0f}")
    print(f"  Max Thrust:      {results['Thrust_kgf'].max():.3f} kgf ({results['Thrust_kgf'].max()*1000:.1f} gf)")
    print(f"  Max Power:       {results['ElecPower_W'].max():.1f} W")
    print(f"  Best Efficiency: {results['Efficiency_g_per_W'].max():.2f} gf/W")
    
    return results

if __name__ == "__main__":
    print("\n" + "=" * 70)
    print("PROPULSION PERFORMANCE CURVE GENERATOR (ENHANCED)")
    print("=" * 70)
    
    # Test with known configuration
    print("\nTest: 2850 Kv, 7x6 prop, 30A ESC, 11.1V")
    generate_prediction_curve(
        motor_kv=2850,
        prop_d=7.0,
        prop_p=6.0,
        esc_limit=30,
        voltage_v=11.1
    )
