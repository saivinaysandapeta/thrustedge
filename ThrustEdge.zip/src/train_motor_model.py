import pandas as pd
import numpy as np
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import r2_score, mean_absolute_error
import joblib

class MotorModelTrainer:
    """
    Train Model B: Electrical/Motor Dynamics
    
    Inputs:  Motor_Kv, Voltage, ESC_limit, Throttle, (Prop_load)
    Outputs: RPM, Current
    
    This model learns how motor spins under electrical input and load
    """
    
    def __init__(self):
        self.model_rpm = None
        self.model_current = None
        self.scaler_motor = None
    
    def prepare_features(self, df):
        """
        Create features for motor/electrical model
        """
        features = pd.DataFrame({
            'Motor_Kv': df['Motor_Kv'],
            'Voltage_V': df['Voltage_V'],
            'ESC_limit_A': df['ESC_limit_A'],
            'Throttle_pct': df['Throttle_pct'],
            'Prop_D_inch': df['Prop_D_inch'],
            'Prop_P_inch': df['Prop_P_inch'],
            'Prop_load': df['Prop_D_inch'] ** 2 * df['Prop_P_inch'],  # Approximate load
        })
        
        return features
    
    def estimate_current(self, elec_power, voltage):
        """Estimate current from power and voltage"""
        if voltage < 1:
            return 0
        return elec_power / voltage
    
    def train(self, data_path="data/processed/physics_dataset.csv"):
        """
        Train motor dynamics models
        """
        
        print("="*70)
        print("TRAINING MODEL B: MOTOR/ELECTRICAL MODEL (RPM, Current)")
        print("="*70)
        
        # Load physics dataset
        df = pd.read_csv(data_path)
        print(f"\nLoaded {len(df)} physics-aware data points")
        
        # Estimate current (if not in dataset)
        if 'Current_A' not in df.columns:
            print("\nEstimating current from power and voltage...")
            df['Current_A'] = df.apply(
                lambda row: self.estimate_current(row['ElecPower_W'], row['Voltage_V']),
                axis=1
            )
        
        # Prepare features
        X = self.prepare_features(df)
        y_rpm = df['RPM'].values
        y_current = df['Current_A'].values
        
        print(f"\nFeature columns: {list(X.columns)}")
        
        # Split
        X_train, X_test, y_rpm_train, y_rpm_test, y_curr_train, y_curr_test = train_test_split(
            X, y_rpm, y_current, test_size=0.2, random_state=42
        )
        
        # Scale features
        self.scaler_motor = StandardScaler()
        X_train_scaled = self.scaler_motor.fit_transform(X_train)
        X_test_scaled = self.scaler_motor.transform(X_test)
        
        # Train RPM model
        print("\n" + "-"*70)
        print("Training RPM model...")
        print("-"*70)
        
        self.model_rpm = GradientBoostingRegressor(
            n_estimators=200,
            max_depth=6,
            learning_rate=0.05,
            random_state=42
        )
        
        self.model_rpm.fit(X_train_scaled, y_rpm_train)
        
        y_rpm_pred_train = self.model_rpm.predict(X_train_scaled)
        y_rpm_pred_test = self.model_rpm.predict(X_test_scaled)
        
        print(f"RPM Model Performance:")
        print(f"  Train R²: {r2_score(y_rpm_train, y_rpm_pred_train):.4f}")
        print(f"  Test R²:  {r2_score(y_rpm_test, y_rpm_pred_test):.4f}")
        print(f"  Test MAE: {mean_absolute_error(y_rpm_test, y_rpm_pred_test):.1f} RPM")
        
        # Train Current model
        print("\n" + "-"*70)
        print("Training Current model...")
        print("-"*70)
        
        self.model_current = GradientBoostingRegressor(
            n_estimators=200,
            max_depth=6,
            learning_rate=0.05,
            random_state=42
        )
        
        self.model_current.fit(X_train_scaled, y_curr_train)
        
        y_curr_pred_train = self.model_current.predict(X_train_scaled)
        y_curr_pred_test = self.model_current.predict(X_test_scaled)
        
        print(f"Current Model Performance:")
        print(f"  Train R²: {r2_score(y_curr_train, y_curr_pred_train):.4f}")
        print(f"  Test R²:  {r2_score(y_curr_test, y_curr_pred_test):.4f}")
        print(f"  Test MAE: {mean_absolute_error(y_curr_test, y_curr_pred_test):.3f} A")
        
        # Save models
        joblib.dump(self.model_rpm, 'models/motor_model_rpm.pkl')
        joblib.dump(self.model_current, 'models/motor_model_current.pkl')
        joblib.dump(self.scaler_motor, 'models/motor_scaler.pkl')
        joblib.dump(list(X.columns), 'models/motor_features.pkl')
        
        print("\n✓ Saved motor models to models/")
        
        return self.model_rpm, self.model_current


if __name__ == "__main__":
    trainer = MotorModelTrainer()
    trainer.train()
