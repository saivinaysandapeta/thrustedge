import joblib
import numpy as np

# Load calibrations
calibrations = joblib.load("models/calibrations/calibration_index.pkl")

# Test with known good data
prop_key = "10.0x4.5"

if prop_key in calibrations:
    cal = calibrations[prop_key]
    
    print("="*70)
    print(f"CALIBRATION CHECK: {prop_key}")
    print("="*70)
    
    print(f"\nCalibration Data:")
    print(f"  Source: {cal['source_file']}")
    print(f"  Data Points: {cal['data_points']}")
    print(f"  RPM Range: {cal['rpm_range'][0]:.0f} - {cal['rpm_range'][1]:.0f}")
    print(f"  C_T Range: {cal['ct_range'][0]:.6f} - {cal['ct_range'][1]:.6f}")
    print(f"  C_T MAPE: {cal['ct_mape']:.2f}%")
    print(f"  C_T Params: {cal['ct_params']}")
    
    # Test prediction
    motor_kv = 1000
    voltage = 11.1
    throttle = 50
    
    rpm = motor_kv * voltage * (throttle / 100)
    print(f"\nTest Case:")
    print(f"  Motor: {motor_kv} KV")
    print(f"  Voltage: {voltage} V")
    print(f"  Throttle: {throttle}%")
    print(f"  Calculated RPM: {rpm:.0f}")
    
    # Calculate C_T
    a, b, c = cal['ct_params']
    ct = a + b * np.log(rpm + 1) + c * rpm / 10000
    
    print(f"\nC_T Calculation:")
    print(f"  a={a:.6f}, b={b:.6f}, c={c:.6f}")
    print(f"  C_T = {ct:.6f}")
    
    # Calculate thrust
    rho = 1.225
    D = 10.0 * 0.0254  # meters
    n = rpm / 60  # Hz
    
    thrust_N = ct * rho * (n ** 2) * (D ** 4)
    thrust_kgf = thrust_N / 9.81
    
    print(f"\nThrust Calculation:")
    print(f"  D = {D:.4f} m")
    print(f"  n = {n:.2f} Hz")
    print(f"  Thrust = {thrust_N:.2f} N = {thrust_kgf:.3f} kgf")
    
    # Compare with expected
    print(f"\n✓ Expected range: 1.5-2.5 kgf at 50% throttle")
    print(f"✓ Calculated: {thrust_kgf:.3f} kgf")
    
    if 1.0 < thrust_kgf < 3.0:
        print("✓ RESULT LOOKS REASONABLE!")
    else:
        print("⚠️ RESULT OUT OF EXPECTED RANGE!")

else:
    print(f"⚠️ No calibration found for {prop_key}")
