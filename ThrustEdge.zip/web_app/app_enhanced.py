from flask import Flask, render_template, request, jsonify, send_file
import joblib
import numpy as np
import pandas as pd
import io
import os

app = Flask(__name__)

# Model directory
MODEL_DIR = "../models"

# Load enhanced models
print("Loading enhanced models...")
try:
    model = joblib.load(f"{MODEL_DIR}/propulsion_model_enhanced.pkl")
    scaler = joblib.load(f"{MODEL_DIR}/feature_scaler_enhanced.pkl")
    features = joblib.load(f"{MODEL_DIR}/feature_columns_enhanced.pkl")
    targets = joblib.load(f"{MODEL_DIR}/target_columns_enhanced.pkl")
    print("✓ Enhanced models loaded successfully!")
    print(f"Features: {len(features)}")
    print(f"Targets: {len(targets)}")
except Exception as e:
    print(f"❌ Error loading enhanced models: {e}")
    print("Train enhanced model: python src/train_model_enhanced.py")
    exit(1)

def create_enhanced_features(motor_kv, prop_d, prop_p, esc_limit, throttle_us, voltage_v):
    """
    Create 15 features in exact order:
    1. Motor_Kv, 2. Prop_D_inch, 3. Prop_P_inch, 4. ESC_limit_A, 5. Voltage_V,
    6. Throttle_norm, 7. Theoretical_RPM, 8. Prop_load, 9. Disc_area,
    10. Tip_speed_factor, 11. Power_density, 12. Aspect_ratio,
    13. V_times_ESC, 14. Throttle_squared, 15. Kv_category
    """
    
    throttle_norm = (throttle_us - 1000) / 1000
    theoretical_rpm = motor_kv * voltage_v * throttle_norm
    prop_load = prop_d ** 2 * prop_p
    disc_area = np.pi * (prop_d / 2) ** 2
    tip_speed_factor = motor_kv * voltage_v * prop_d * throttle_norm
    power_density = motor_kv * voltage_v / (esc_limit + 0.1)
    aspect_ratio = prop_d / (prop_p + 0.1)
    v_times_esc = voltage_v * esc_limit
    throttle_squared = throttle_norm ** 2
    
    if motor_kv < 1500:
        kv_category = 0.0
    elif motor_kv < 3000:
        kv_category = 1.0
    else:
        kv_category = 2.0
    
    return [
        motor_kv, prop_d, prop_p, esc_limit, voltage_v,
        throttle_norm, theoretical_rpm, prop_load, disc_area,
        tip_speed_factor, power_density, aspect_ratio,
        v_times_esc, throttle_squared, kv_category
    ]

def apply_physics_constraints(predictions, throttle_points, motor_kv, prop_d, voltage):
    """
    Apply intelligent physics-based corrections
    Handles model's weakness at low throttle and extrapolation
    """
    corrected = predictions.copy()
    
    for i, throttle in enumerate(throttle_points):
        rpm = corrected[i, 0]
        thrust = corrected[i, 1]
        power = corrected[i, 2]
        
        throttle_pct = (throttle - 1000) / 1000
        
        # RULE 1: Very low throttle = motor off
        if throttle < 1100:
            corrected[i, 0] = 0
            corrected[i, 1] = 0
            corrected[i, 2] = 0
            continue
        
        # RULE 2: All values non-negative
        rpm = max(0, rpm)
        thrust = max(0, thrust)
        power = max(0, power)
        
        # RULE 3: RPM sanity check based on Kv × V × throttle
        expected_rpm_range = motor_kv * voltage * throttle_pct
        
        if rpm < expected_rpm_range * 0.2:  # Too low
            rpm = expected_rpm_range * 0.4  # Conservative
        elif rpm > expected_rpm_range * 1.3:  # Too high (with load)
            rpm = expected_rpm_range * 0.85
        
        # RULE 4: Thrust physical bounds
        # Max thrust ≈ k × (RPM/1000)² × D⁴
        max_thrust = 0.000015 * ((rpm / 1000) ** 2) * (prop_d ** 4)
        if thrust > max_thrust:
            thrust = max_thrust * 0.9
        
        # RULE 5: Power bounds
        if rpm > 1000:
            min_power = 0.0000001 * ((rpm / 1000) ** 3) * (prop_d ** 5)
            if power < min_power:
                power = min_power
        
        max_power = voltage * 100  # ~100A max
        if power > max_power:
            power = max_power
        
        corrected[i, 0] = rpm
        corrected[i, 1] = thrust
        corrected[i, 2] = power
    
    return corrected

def validate_configuration(motor_kv, prop_d, prop_p, esc_limit, voltage):
    """Validate inputs"""
    
    errors = []
    warnings = []
    
    # Hard limits
    if motor_kv < 50 or motor_kv > 15000:
        errors.append("Motor Kv: 50-15000 range")
    if prop_d < 1 or prop_d > 40:
        errors.append("Propeller diameter: 1-40 inches")
    if prop_p < 0.5 or prop_p > 30:
        errors.append("Propeller pitch: 0.5-30 inches")
    if esc_limit < 1 or esc_limit > 500:
        errors.append("ESC limit: 1-500A")
    if voltage < 1 or voltage > 100:
        errors.append("Voltage: 1-100V")
    
    # Warnings
    if motor_kv < 500:
        warnings.append(f"Low Kv ({motor_kv}) - limited training data")
    if motor_kv > 5000:
        warnings.append(f"High Kv ({motor_kv}) - sparse training data")
    if prop_d >= 10 and not (850 <= motor_kv <= 950):
        warnings.append(f"Large prop ({prop_d}\") mainly tested with 900-910 Kv")
    if motor_kv < 1500 and prop_d > 8:
        warnings.append("Low Kv + large prop - moderate extrapolation")
    
    return errors, warnings

@app.route('/')
def index():
    return render_template('index_enhanced.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        data = request.json
        
        motor_kv = float(data['motor_kv'])
        prop_d = float(data['prop_diameter'])
        prop_p = float(data['prop_pitch'])
        esc_limit = float(data['esc_limit'])
        voltage = float(data['voltage'])
        throttle_start = int(data.get('throttle_start', 1000))
        throttle_end = int(data.get('throttle_end', 2000))
        throttle_step = int(data.get('throttle_step', 50))
        
        # Validate
        errors, warnings = validate_configuration(motor_kv, prop_d, prop_p, esc_limit, voltage)
        
        if errors:
            return jsonify({'success': False, 'error': ' | '.join(errors)}), 400
        
        # Generate predictions
        throttle_points = list(range(throttle_start, throttle_end + 1, throttle_step))
        
        X_list = []
        for throttle in throttle_points:
            features_row = create_enhanced_features(
                motor_kv, prop_d, prop_p, esc_limit, throttle, voltage
            )
            X_list.append(features_row)
        
        X = np.array(X_list)
        X_scaled = scaler.transform(X)
        raw_predictions = model.predict(X_scaled)
        
        # Apply physics corrections
        corrected_predictions = apply_physics_constraints(
            raw_predictions, throttle_points, motor_kv, prop_d, voltage
        )
        
        # Format results
        results = []
        for i, throttle in enumerate(throttle_points):
            rpm = float(corrected_predictions[i, 0])
            thrust = float(corrected_predictions[i, 1])
            power = float(corrected_predictions[i, 2])
            
            results.append({
                'throttle': int(throttle),
                'rpm': round(rpm, 1),
                'thrust': round(thrust, 4),
                'power': round(power, 2),
                'efficiency': round((thrust * 1000) / (power + 0.1), 2)
            })
        
        response = {'success': True, 'results': results, 'model_type': 'enhanced'}
        
        if warnings:
            response['warnings'] = warnings
        
        return jsonify(response)
        
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/download', methods=['POST'])
def download():
    try:
        data = request.json
        
        motor_kv = float(data['motor_kv'])
        prop_d = float(data['prop_diameter'])
        prop_p = float(data['prop_pitch'])
        esc_limit = float(data['esc_limit'])
        voltage = float(data['voltage'])
        throttle_start = int(data.get('throttle_start', 1000))
        throttle_end = int(data.get('throttle_end', 2000))
        throttle_step = int(data.get('throttle_step', 50))
        
        errors, warnings = validate_configuration(motor_kv, prop_d, prop_p, esc_limit, voltage)
        
        throttle_points = list(range(throttle_start, throttle_end + 1, throttle_step))
        
        X_list = []
        for throttle in throttle_points:
            features_row = create_enhanced_features(
                motor_kv, prop_d, prop_p, esc_limit, throttle, voltage
            )
            X_list.append(features_row)
        
        X = np.array(X_list)
        X_scaled = scaler.transform(X)
        raw_predictions = model.predict(X_scaled)
        
        corrected_predictions = apply_physics_constraints(
            raw_predictions, throttle_points, motor_kv, prop_d, voltage
        )
        
        df = pd.DataFrame({
            'Motor_Kv': motor_kv,
            'Prop_D_inch': prop_d,
            'Prop_P_inch': prop_p,
            'ESC_limit_A': esc_limit,
            'Voltage_V': voltage,
            'Throttle_us': throttle_points,
            'RPM': corrected_predictions[:, 0],
            'Thrust_kgf': corrected_predictions[:, 1],
            'ElecPower_W': corrected_predictions[:, 2],
            'Efficiency_gf_per_W': (corrected_predictions[:, 1] * 1000) / (corrected_predictions[:, 2] + 0.1)
        })
        
        output = io.StringIO()
        
        if warnings:
            output.write("# WARNINGS:\n")
            for w in warnings:
                output.write(f"# {w}\n")
            output.write("#\n")
        
        df.to_csv(output, index=False)
        output.seek(0)
        
        filename = f"prediction_{int(motor_kv)}kv_{prop_d}x{prop_p}_{voltage}v_enhanced.csv"
        
        return send_file(
            io.BytesIO(output.getvalue().encode()),
            mimetype='text/csv',
            as_attachment=True,
            download_name=filename
        )
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/health')
def health():
    return jsonify({
        'status': 'healthy',
        'model': 'enhanced',
        'features': len(features),
        'targets': len(targets)
    })

if __name__ == '__main__':
    print("\n" + "="*70)
    print("ENHANCED PROPULSION PREDICTION - PHYSICS-CORRECTED")
    print("="*70)
    print("\nModel: Enhanced (15 physics features)")
    print("Features:")
    print("  ✓ Physics-based feature engineering")
    print("  ✓ Handles unknown combinations")
    print("  ✓ Intelligent low-throttle correction")
    print("  ✓ No negative values")
    print("  ✓ Extrapolation warnings")
    print("\nStarting at http://localhost:5000")
    print("="*70 + "\n")
    
    app.run(debug=True, host='0.0.0.0', port=5000)
