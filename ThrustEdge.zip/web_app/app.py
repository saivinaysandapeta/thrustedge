from flask import Flask, request, jsonify, render_template_string
import joblib
import numpy as np
import pandas as pd
import os

app = Flask(__name__)

MODEL_DIR = "../models"

# Load models at startup
print("Loading models...")
model = joblib.load(f"{MODEL_DIR}/propulsion_model.pkl")
scaler = joblib.load(f"{MODEL_DIR}/feature_scaler.pkl")
feature_cols = joblib.load(f"{MODEL_DIR}/feature_columns.pkl")
target_cols = joblib.load(f"{MODEL_DIR}/target_columns.pkl")
print(f"✓ Loaded model with features: {feature_cols}")
print(f"✓ Targets: {target_cols}")

HTML = """
<!DOCTYPE html>
<html>
<head>
    <title>🚁 Propulsion Predictor</title>
    <meta charset="UTF-8">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        .container { 
            max-width: 900px;
            margin: 0 auto;
            background: white;
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        }
        h1 { 
            color: #333;
            margin-bottom: 10px;
            font-size: 2.5em;
        }
        .subtitle {
            color: #666;
            margin-bottom: 30px;
            font-size: 1.1em;
        }
        .form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 20px;
        }
        .form-group {
            display: flex;
            flex-direction: column;
        }
        label { 
            font-weight: 600;
            color: #555;
            margin-bottom: 8px;
            font-size: 0.95em;
        }
        input { 
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 16px;
            transition: all 0.3s;
        }
        input:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }
        button { 
            width: 100%;
            padding: 15px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            font-size: 18px;
            font-weight: 600;
            transition: transform 0.2s, box-shadow 0.2s;
            margin-top: 10px;
        }
        button:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(102, 126, 234, 0.3);
        }
        button:active {
            transform: translateY(0);
        }
        .result { 
            margin-top: 30px;
            padding: 25px;
            background: #f8f9fa;
            border-radius: 12px;
            display: none;
            border-left: 5px solid #667eea;
        }
        .result.show { display: block; }
        .result h3 {
            color: #667eea;
            margin-bottom: 15px;
            font-size: 1.5em;
        }
        .info-box {
            background: white;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 15px;
            font-size: 0.95em;
            color: #555;
        }
        pre { 
            background: #2d2d2d;
            color: #f8f8f2;
            padding: 15px;
            border-radius: 8px;
            overflow-x: auto;
            font-size: 0.85em;
            line-height: 1.5;
        }
        .btn-download {
            background: #28a745;
            margin-top: 15px;
        }
        .btn-download:hover {
            background: #218838;
        }
        .loading {
            display: none;
            text-align: center;
            padding: 20px;
            color: #667eea;
            font-weight: 600;
        }
        .loading.show { display: block; }
        .spinner {
            border: 3px solid #f3f3f3;
            border-top: 3px solid #667eea;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            animation: spin 1s linear infinite;
            margin: 0 auto 10px;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        .feature-badge {
            display: inline-block;
            background: #e3f2fd;
            color: #1976d2;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.85em;
            margin: 5px 5px 5px 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🚁 Propulsion System Predictor</h1>
        <p class="subtitle">AI-powered performance prediction for drone propulsion systems</p>
        
        <div>
            <span class="feature-badge">Motor Kv</span>
            <span class="feature-badge">ESC Rating</span>
            <span class="feature-badge">Battery Voltage</span>
            <span class="feature-badge">Propeller Size</span>
        </div>
        
        <form id="form">
            <div class="form-grid">
                <div class="form-group">
                    <label>🔧 Motor Kv (RPM/V)</label>
                    <input type="number" id="motor_kv" value="2850" required>
                </div>
                
                <div class="form-group">
                    <label>⚡ ESC Limit (A)</label>
                    <input type="number" id="esc_limit" value="30" required>
                </div>
                
                <div class="form-group">
                    <label>🔋 Battery Voltage (V)</label>
                    <input type="number" step="0.1" id="battery_v" value="11.1" required>
                </div>
                
                <div class="form-group">
                    <label>📏 Propeller Diameter (inch)</label>
                    <input type="number" step="0.1" id="prop_d" value="7.0" required>
                </div>
                
                <div class="form-group">
                    <label>📐 Propeller Pitch (inch)</label>
                    <input type="number" step="0.1" id="prop_p" value="6.0" required>
                </div>
                
                <div class="form-group">
                    <label>🎚️ Throttle Min (µs)</label>
                    <input type="number" id="throttle_min" value="1100" required>
                </div>
                
                <div class="form-group">
                    <label>🎚️ Throttle Max (µs)</label>
                    <input type="number" id="throttle_max" value="1900" required>
                </div>
                
                <div class="form-group">
                    <label>📊 Throttle Step (µs)</label>
                    <input type="number" id="throttle_step" value="50" required>
                </div>
            </div>
            
            <button type="submit">🚀 Generate Prediction</button>
        </form>
        
        <div class="loading" id="loading">
            <div class="spinner"></div>
            <p>Generating predictions...</p>
        </div>
        
        <div class="result" id="result">
            <h3>✅ Prediction Complete!</h3>
            <div class="info-box" id="info"></div>
            <button class="btn-download" onclick="downloadCSV()">📥 Download CSV File</button>
            <h4 style="margin-top: 20px; color: #555;">Preview (first 10 rows):</h4>
            <pre id="preview"></pre>
        </div>
    </div>
    
    <script>
        let csvData = '';
        
        document.getElementById('form').addEventListener('submit', async (e) => {
            e.preventDefault();
            
            document.getElementById('loading').classList.add('show');
            document.getElementById('result').classList.remove('show');
            
            const data = {
                motor_kv: parseFloat(document.getElementById('motor_kv').value),
                esc_limit: parseFloat(document.getElementById('esc_limit').value),
                battery_v: parseFloat(document.getElementById('battery_v').value),
                prop_d: parseFloat(document.getElementById('prop_d').value),
                prop_p: parseFloat(document.getElementById('prop_p').value),
                throttle_min: parseInt(document.getElementById('throttle_min').value),
                throttle_max: parseInt(document.getElementById('throttle_max').value),
                throttle_step: parseInt(document.getElementById('throttle_step').value),
            };
            
            try {
                const response = await fetch('/predict-csv', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify(data)
                });
                
                const result = await response.json();
                csvData = result.csv;
                
                document.getElementById('info').innerHTML = `
                    <strong>Configuration:</strong><br>
                    Motor: ${data.motor_kv} Kv | ESC: ${data.esc_limit}A | Battery: ${data.battery_v}V<br>
                    Propeller: ${data.prop_d}" × ${data.prop_p}" | 
                    Throttle: ${data.throttle_min}-${data.throttle_max}µs (step: ${data.throttle_step}µs)<br>
                    <strong>Predictions:</strong> ${result.rows} data points generated
                `;
                
                const lines = csvData.split('\\n').slice(0, 11).join('\\n');
                document.getElementById('preview').textContent = lines;
                
                document.getElementById('loading').classList.remove('show');
                document.getElementById('result').classList.add('show');
            } catch (error) {
                alert('Error generating prediction: ' + error);
                document.getElementById('loading').classList.remove('show');
            }
        });
        
        function downloadCSV() {
            const data = {
                motor_kv: document.getElementById('motor_kv').value,
                esc_limit: document.getElementById('esc_limit').value,
                battery_v: document.getElementById('battery_v').value,
                prop_d: document.getElementById('prop_d').value,
                prop_p: document.getElementById('prop_p').value,
            };
            
            const filename = `prediction_${data.motor_kv}kv_${data.prop_d}x${data.prop_p}_${data.esc_limit}A_${data.battery_v}V.csv`;
            
            const blob = new Blob([csvData], {type: 'text/csv'});
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = filename;
            a.click();
            window.URL.revokeObjectURL(url);
        }
    </script>
</body>
</html>
"""

@app.route("/")
def index():
    return render_template_string(HTML)

@app.route("/predict-csv", methods=["POST"])
def predict_csv():
    data = request.json
    motor_kv = float(data["motor_kv"])
    esc_limit = float(data["esc_limit"])
    battery_v = float(data["battery_v"])
    prop_d = float(data["prop_d"])
    prop_p = float(data["prop_p"])
    
    throttle_min = int(data.get("throttle_min", 1100))
    throttle_max = int(data.get("throttle_max", 1900))
    throttle_step = int(data.get("throttle_step", 50))
    
    throttles = np.arange(throttle_min, throttle_max + 1, throttle_step)
    rows = []
    
    for t in throttles:
        feature_dict = {
            "Motor_Kv": motor_kv,
            "Prop_D_inch": prop_d,
            "Prop_P_inch": prop_p,
            "ESC_limit_A": esc_limit,
            "Throttle_us": t,
            "Voltage_V": battery_v,
        }
        x = np.array([[feature_dict[c] for c in feature_cols]])
        x_scaled = scaler.transform(x)
        y_pred = model.predict(x_scaled)[0]
        
        row = {"Throttle_us": t, **feature_dict}
        for name, value in zip(target_cols, y_pred):
            row[name] = value
        rows.append(row)
    
    df = pd.DataFrame(rows)
    csv_str = df.to_csv(index=False)
    
    return jsonify({
        "status": "ok",
        "csv": csv_str,
        "rows": len(rows)
    })

if __name__ == "__main__":
    print("\n" + "="*60)
    print("🌐 PROPULSION PREDICTOR WEB SERVER")
    print("="*60)
    print(f"\n✓ Model loaded: {len(target_cols)} outputs")
    print(f"✓ Features: {', '.join(feature_cols)}")
    print(f"✓ Targets: {', '.join(target_cols)}")
    print("\n" + "="*60)
    print("🚀 Server starting...")
    print("="*60)
    print("\n📍 Open your browser to: http://localhost:5000")
    print("\n⌨️  Press Ctrl+C to stop the server\n")
    app.run(debug=True, port=5000, host='0.0.0.0')
